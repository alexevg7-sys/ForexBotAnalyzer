from __future__ import annotations
import os
from typing import Optional, Dict
import pandas as pd

class MarketCache:
    """
    Локален кеш за OHLC c ретенция по TF.
    Път: data/ohlc/{PAIR}_{TF}.csv    (PAIR: EUR_USD, TF: 15min|1h|4h)
    """
    def __init__(self, base_dir: str, retention_days: int = 7,
                 retention_by_tf: Optional[Dict[str, int]] = None):
        self.base_dir = base_dir
        self.retention_default = int(retention_days)
        # професионална ретенция по TF
        self.retention_by_tf = retention_by_tf or {
            "15min": 14,   # 2 седмици
            "1h":    30,   # 1 месец
            "4h":   120,   # ~4 месеца
        }
        self.ohlc_dir = os.path.join(self.base_dir, "ohlc")
        os.makedirs(self.ohlc_dir, exist_ok=True)

    # ---------- helpers ----------
    def _slug_pair(self, pair: str) -> str:
        return pair.replace("/", "_").replace("\\", "_").replace(" ", "").upper()

    def _tf_slug(self, tf: str) -> str:
        iv = (tf or "").lower().strip()
        mapping = {
            "15m": "15min", "15min": "15min",
            "60m": "1h", "60min": "1h", "1h": "1h",
            "240m": "4h", "240min": "4h", "4h": "4h",
        }
        return mapping.get(iv, iv)

    def _ret_days(self, tf: str) -> int:
        tf_s = self._tf_slug(tf)
        return int(self.retention_by_tf.get(tf_s, self.retention_default))

    def _path(self, pair: str, tf: str) -> str:
        fname = f"{self._slug_pair(pair)}_{self._tf_slug(tf)}.csv"
        return os.path.join(self.ohlc_dir, fname)

    # ---------- public API ----------
    def save(self, pair: str, tf: str, df_new: pd.DataFrame) -> None:
        """
        df_new: колони ['datetime','open','high','low','close'(,'volume')]
        Обединява с наличното, маха дубликати, сортира и чисти според TF ретенцията.
        """
        if df_new is None or df_new.empty:
            return

        need = ["datetime", "open", "high", "low", "close"]
        for c in need:
            if c not in df_new.columns:
                raise ValueError(f"save(): missing column '{c}' in df_new")

        df_new = df_new.copy()
        df_new["datetime"] = pd.to_datetime(df_new["datetime"], utc=True, errors="coerce")
        for c in ["open", "high", "low", "close"]:
            df_new[c] = pd.to_numeric(df_new[c], errors="coerce")
        if "volume" not in df_new.columns:
            df_new["volume"] = 0.0
        else:
            df_new["volume"] = pd.to_numeric(df_new["volume"], errors="coerce").fillna(0.0)

        path = self._path(pair, tf)

        if os.path.exists(path):
            try:
                df_old = pd.read_csv(path, parse_dates=["datetime"])
            except Exception:
                df_old = pd.DataFrame(columns=["datetime","open","high","low","close","volume"])
        else:
            df_old = pd.DataFrame(columns=["datetime","open","high","low","close","volume"])

        if not df_old.empty:
            df_old["datetime"] = pd.to_datetime(df_old["datetime"], utc=True, errors="coerce")
            for c in ["open","high","low","close","volume"]:
                if c in df_old.columns:
                    df_old[c] = pd.to_numeric(df_old[c], errors="coerce")

        df = pd.concat([df_old, df_new], ignore_index=True)
        df = df.drop_duplicates(subset=["datetime"], keep="last").sort_values("datetime").reset_index(drop=True)

        # ротация според TF
        keep_days = self._ret_days(tf)
        if keep_days and not df.empty:
            cutoff = df["datetime"].max() - pd.Timedelta(days=keep_days)
            df = df[df["datetime"] >= cutoff]

        df.to_csv(path, index=False)

    def load(self, pair: str, tf: str) -> pd.DataFrame:
        path = self._path(pair, tf)
        if not os.path.exists(path):
            return pd.DataFrame(columns=["datetime","open","high","low","close","volume"])
        try:
            return pd.read_csv(path, parse_dates=["datetime"])
        except Exception:
            return pd.DataFrame(columns=["datetime","open","high","low","close","volume"])

    # aliases
    def get(self, pair: str, tf: str) -> pd.DataFrame:
        return self.load(pair, tf)

    def last(self, pair: str, tf: str, n: int = 200) -> pd.DataFrame:
        df = self.load(pair, tf)
        return df.tail(int(n)).reset_index(drop=True) if not df.empty else df
