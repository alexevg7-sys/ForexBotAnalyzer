from __future__ import annotations

import os
import time
from typing import Iterable
import shutil


def purge_old_files(paths: Iterable[str], older_than_days: int, logger) -> dict:
    """
    Изтрива рекурсивно файлове/папки по-стари от older_than_days (по mtime).
    Връща статистика: {"files": N, "dirs": M, "errors": K}
    """
    cutoff = time.time() - older_than_days * 24 * 3600
    stats = {"files": 0, "dirs": 0, "errors": 0}

    for root in paths:
        if not os.path.exists(root):
            continue
        for dirpath, dirnames, filenames in os.walk(root, topdown=False):
            # Файлове
            for fname in filenames:
                fpath = os.path.join(dirpath, fname)
                try:
                    if os.path.getmtime(fpath) < cutoff:
                        os.unlink(fpath)
                        stats["files"] += 1
                except Exception as e:
                    logger.error("cleanup:file", path=fpath, err=str(e))
                    stats["errors"] += 1
            # Папки (ако са празни и стари)
            for dname in dirnames:
                dpath = os.path.join(dirpath, dname)
                try:
                    if not os.listdir(dpath) and os.path.getmtime(dpath) < cutoff:
                        shutil.rmtree(dpath, ignore_errors=True)
                        stats["dirs"] += 1
                except Exception as e:
                    logger.error("cleanup:dir", path=dpath, err=str(e))
                    stats["errors"] += 1

    return stats
