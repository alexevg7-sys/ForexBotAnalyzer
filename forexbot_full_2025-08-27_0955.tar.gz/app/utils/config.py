from __future__ import annotations

import os
import time
from typing import List, Optional

from dotenv import load_dotenv
from pydantic import BaseModel, Field, field_validator, ValidationError


ENV_PATH_DEFAULT = "/OPT/forexbot/.env"


def _split_csv(value: str) -> List[str]:
    return [x.strip() for x in value.split(",") if x.strip()]


def _mask(token: Optional[str], show: int = 4) -> str:
    if not token:
        return ""
    if len(token) <= show:
        return "*" * len(token)
    return token[:show] + "…" + "*" * max(0, len(token) - show - 1)


class Settings(BaseModel):
    # App
    app_name: str = Field(default="forexbot")
    env: str = Field(default="prod")
    timezone: str = Field(default="Europe/Sofia")

    # Paths
    data_dir: str
    log_dir: str
    state_dir: str
    tmp_dir: str

    # Telegram
    telegram_bot_token: str
    telegram_target_chat_id: List[int]

    # APIs
    twelvedata_api_key: str
    finnhub_api_key: str
    deepl_api_key: str

    # Markets / TFs
    default_pairs: List[str]
    tf_h1: str = Field(default="60min")
    tf_m15: str = Field(default="15min")
    tf_h4: str = Field(default="240min")

    # Limits / cadence
    rate_limit_per_min: int = Field(default=55)
    poll_interval_seconds: int = Field(default=20)
    news_refresh_seconds: int = Field(default=60)

    # Signals
    signal_min_confidence: int = Field(default=70)
    max_tps: int = Field(default=2)
    risk_rr_base: float = Field(default=1.5)

    # Retention
    data_retention_days: int = Field(default=7)

    # Logging
    log_level: str = Field(default="INFO")

    # -------- Validators --------
    @field_validator("telegram_target_chat_id", mode="before")
    @classmethod
    def _parse_chat_ids(cls, v):
        if isinstance(v, list):
            return [int(x) for x in v]
        if isinstance(v, str):
            return [int(x) for x in _split_csv(v)]
        raise ValueError("Invalid TELEGRAM_TARGET_CHAT_ID")

    @field_validator("default_pairs", mode="before")
    @classmethod
    def _parse_pairs(cls, v):
        if isinstance(v, list):
            return [x.upper() for x in v]
        if isinstance(v, str):
            return [x.upper() for x in _split_csv(v)]
        raise ValueError("Invalid DEFAULT_PAIRS")

    @field_validator("log_level")
    @classmethod
    def _lvl(cls, v: str):
        v2 = v.upper()
        if v2 not in {"DEBUG", "INFO", "WARNING", "ERROR"}:
            return "INFO"
        return v2

    @classmethod
    def from_env(cls, env_path: str = ENV_PATH_DEFAULT) -> "Settings":
        # Load .env into process env; do not error if missing (we expect it)
        load_dotenv(env_path, override=True)

        # Build dict from environment (explicit mapping)
        data = {
            "app_name": os.getenv("APP_NAME", "forexbot"),
            "env": os.getenv("ENV", "prod"),
            "timezone": os.getenv("TIMEZONE", "Europe/Sofia"),

            "data_dir": os.getenv("DATA_DIR", "/OPT/forexbot/data"),
            "log_dir": os.getenv("LOG_DIR", "/OPT/forexbot/logs"),
            "state_dir": os.getenv("STATE_DIR", "/OPT/forexbot/state"),
            "tmp_dir": os.getenv("TMP_DIR", "/OPT/forexbot/tmp"),

            "telegram_bot_token": os.getenv("TELEGRAM_BOT_TOKEN", ""),
            "telegram_target_chat_id": os.getenv("TELEGRAM_TARGET_CHAT_ID", ""),

            "twelvedata_api_key": os.getenv("TWELVEDATA_API_KEY", ""),
            "finnhub_api_key": os.getenv("FINNHUB_API_KEY", ""),
            "deepl_api_key": os.getenv("DEEPL_API_KEY", ""),

            "default_pairs": os.getenv("DEFAULT_PAIRS", ""),

            "tf_h1": os.getenv("TF_H1", "60min"),
            "tf_m15": os.getenv("TF_M15", "15min"),
            "tf_h4": os.getenv("TF_H4", "240min"),

            "rate_limit_per_min": int(os.getenv("RATE_LIMIT_PER_MIN", "55")),
            "poll_interval_seconds": int(os.getenv("POLL_INTERVAL_SECONDS", "20")),
            "news_refresh_seconds": int(os.getenv("NEWS_REFRESH_SECONDS", "60")),

            "signal_min_confidence": int(os.getenv("SIGNAL_MIN_CONFIDENCE", "70")),
            "max_tps": int(os.getenv("MAX_TPS", "2")),
            "risk_rr_base": float(os.getenv("RISK_RR_BASE", "1.5")),

            "data_retention_days": int(os.getenv("DATA_RETENTION_DAYS", "7")),
            "log_level": os.getenv("LOG_LEVEL", "INFO"),
        }

        try:
            settings = cls(**data)
        except ValidationError as e:
            raise SystemExit(f"[config] Invalid configuration: {e}") from e

        # Ensure TZ is applied on POSIX
        try:
            os.environ["TZ"] = settings.timezone
            if hasattr(time, "tzset"):
                time.tzset()
        except Exception:
            pass

        # Ensure dirs exist
        for p in [settings.data_dir, settings.log_dir, settings.state_dir, settings.tmp_dir]:
            os.makedirs(p, exist_ok=True)

        return settings

    def safe_summary(self) -> str:
        return (
            f"app={self.app_name} env={self.env} tz={self.timezone} "
            f"pairs={len(self.default_pairs)} tf(H1/M15/H4)={self.tf_h1}/{self.tf_m15}/{self.tf_h4} "
            f"rate_limit/min={self.rate_limit_per_min} retention_days={self.data_retention_days} "
            f"telegram_chats={len(self.telegram_target_chat_id)} "
            f"keys: TG={_mask(self.telegram_bot_token)} TD={_mask(self.twelvedata_api_key)} "
            f"FH={_mask(self.finnhub_api_key)} DL={_mask(self.deepl_api_key)}"
        )
