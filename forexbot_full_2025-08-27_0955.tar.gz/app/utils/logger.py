import logging
import os
from typing import Optional


def configure_logging(level: str = "INFO", log_dir: Optional[str] = None) -> None:
    level_value = getattr(logging, level.upper(), logging.INFO)

    # Подгответе ротация в следваща стъпка; за сега — стандартен формат
    fmt = "[%(asctime)s] %(levelname)s %(name)s — %(message)s"
    datefmt = "%Y-%m-%d %H:%M:%S"

    # Ако има log_dir, уверяваме се че съществува
    if log_dir:
        os.makedirs(log_dir, exist_ok=True)

    logging.basicConfig(
        level=level_value,
        format=fmt,
        datefmt=datefmt,
    )


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)
