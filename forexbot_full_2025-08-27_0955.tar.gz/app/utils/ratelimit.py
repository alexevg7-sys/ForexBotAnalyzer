from __future__ import annotations

import asyncio
import time
from collections import deque

class RateLimiter:
    """
    Пример: limiter = RateLimiter(max_calls=50, per_seconds=60)
    await limiter.acquire() преди всяка външна заявка (TwelveData/Finnhub).
    """
    def __init__(self, max_calls: int, per_seconds: float):
        self.max_calls = int(max_calls)
        self.per = float(per_seconds)
        self._ts = deque()
        self._lock = asyncio.Lock()

    async def acquire(self):
        async with self._lock:
            now = time.monotonic()
            while self._ts and (now - self._ts[0]) > self.per:
                self._ts.popleft()
            if len(self._ts) >= self.max_calls:
                sleep_for = self.per - (now - self._ts[0]) + 0.01
                await asyncio.sleep(max(0.0, sleep_for))
                now = time.monotonic()
                while self._ts and (now - self._ts[0]) > self.per:
                    self._ts.popleft()
            self._ts.append(time.monotonic())
