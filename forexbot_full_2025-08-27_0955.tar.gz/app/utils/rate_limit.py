from __future__ import annotations

from aiolimiter import AsyncLimiter


class RateLimiter:
    """
    Прост wrapper над aiolimiter.AsyncLimiter
    пример:
        limiter = RateLimiter(55, 60)
        async with limiter:
            await do_request()
    """
    def __init__(self, max_rate: int, time_period_seconds: float):
        self._limiter = AsyncLimiter(max_rate, time_period_seconds)

    async def __aenter__(self):
        await self._limiter.acquire()
        return self

    async def __aexit__(self, exc_type, exc, tb):
        # освобождава се автоматично от AsyncLimiter
        return False
