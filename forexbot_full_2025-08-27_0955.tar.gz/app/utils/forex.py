from __future__ import annotations

from typing import Tuple


def split_pair(pair: str) -> Tuple[str, str]:
    # "EUR/USD" -> ("EUR","USD")
    p = pair.replace(" ", "").upper()
    if "/" in p:
        a, b = p.split("/", 1)
    elif "_" in p:
        a, b = p.split("_", 1)
    else:
        # fallback
        a, b = p[:3], p[3:6]
    return a, b


def pip_info(pair: str) -> Tuple[float, int]:
    """
    Връща (pip_value, decimals_for_quote)
    - JPY кросове: 1 pip = 0.01 (2 знака, често котират 3)
    - останалите: 1 pip = 0.0001 (4 знака, често котират 5)
    Използваме +1 знак за по-финно TP/SL.
    """
    base, quote = split_pair(pair)
    if "JPY" in (base, quote):
        return 0.01, 3
    return 0.0001, 5


def round_price(pair: str, price: float) -> float:
    _, dec = pip_info(pair)
    fmt = "{:." + str(dec) + "f}"
    return float(fmt.format(price))


def add_pips(pair: str, price: float, pips: float) -> float:
    pip, _ = pip_info(pair)
    return price + pips * pip
