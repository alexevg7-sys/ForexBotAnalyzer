from __future__ import annotations

import re
from typing import Dict, Iterable, List, Tuple


# Мапване на ключови думи -> валута
_CCY_KEYWORDS = {
    "USD": [r"\busd\b", r"\bdollar(s)?\b", r"\bfed(eral)?\b", r"\bu\.?s\.?\b", r"\bunited states\b"],
    "EUR": [r"\beur\b", r"\beuro\b", r"\becb\b", r"\beuro(zone)?\b"],
    "GBP": [r"\bgbp\b", r"\bpound\b", r"\bboe\b", r"\buk\b", r"\bunited kingdom\b", r"\bbritain\b"],
    "JPY": [r"\bjpy\b", r"\byen\b", r"\bboj\b", r"\bjapan\b"],
    "CHF": [r"\bchf\b", r"\bfranc\b", r"\bsnb\b", r"\bswiss\b", r"\bswitzerland\b"],
    "CAD": [r"\bcad\b", r"\bloonie\b", r"\bboc\b", r"\bcanada\b"],
    "AUD": [r"\baud\b", r"\baustralia(n)?\b", r"\brba\b"],
    "NZD": [r"\bnzd\b", r"\bnew zealand\b", r"\brbnz\b", r"\bnz\b"],
    "SEK": [r"\bsek\b", r"\bsweden\b", r"\briksbank\b"],
    "NOK": [r"\bnok\b", r"\bnorway\b", r"\bnorges bank\b"],
    "TRY": [r"\btry\b", r"\bturkey\b", r"\blira\b", r"\bcbt\b"],
    "ZAR": [r"\bzar\b", r"\brand\b", r"\bsouth africa\b", r"\bsarb\b"],
}

# Ключови думи за важност/посока
_HIGH_IMPACT = [
    r"\brate(s)? (decision|hike|cut|hold)\b",
    r"\bcpi\b", r"\binflation\b", r"\bnfp\b", r"\bpayroll(s)?\b", r"\bgdp\b",
    r"\bquantitative (tightening|easing)\b", r"\bpolicy\b",
]
_MED_IMPACT = [
    r"\bpmi\b", r"\bconfidence\b", r"\bretail sales\b", r"\bunemployment\b",
    r"\bminutes\b", r"\bspeech\b", r"\bremarks\b", r"\bforecast\b",
]
_POSITIVE = [
    r"\bbeat(s|en)?\b", r"\brise(s|n)?\b", r"\baccelerat(es|ed|ion)\b",
    r"\bhawkish\b", r"\bstrong\b", r"\bgrowth\b", r"\bexpand(s|ed|ion)\b",
    r"\btighten(s|ed|ing)\b",
]
_NEGATIVE = [
    r"\bmiss(es|ed)?\b", r"\bfall(s|en)?\b", r"\bcontract(s|ed|ion)\b",
    r"\bdovish\b", r"\bweak\b", r"\brecession\b", r"\bslow(s|ed|ing)?\b",
    r"\bcut(s|ting)?\b",
]

_rx = lambda pats: [re.compile(p, re.I) for p in pats]
_HIGH_IMPACT_RX = _rx(_HIGH_IMPACT)
_MED_IMPACT_RX  = _rx(_MED_IMPACT)
_POS_RX = _rx(_POSITIVE)
_NEG_RX = _rx(_NEGATIVE)

_CCY_RX = {ccy: _rx(pats) for ccy, pats in _CCY_KEYWORDS.items()}


def _count_matches(rx_list: List[re.Pattern], text: str) -> int:
    return sum(1 for rx in rx_list if rx.search(text))


def extract_currencies(text: str, max_ccy: int = 4) -> List[str]:
    scores = {}
    for ccy, rx_list in _CCY_RX.items():
        c = _count_matches(rx_list, text)
        if c:
            scores[ccy] = c
    # връщаме до max_ccy по най-висок score
    return [k for k, _ in sorted(scores.items(), key=lambda kv: kv[1], reverse=True)][:max_ccy]


def importance_stars(text: str) -> int:
    hi = _count_matches(_HIGH_IMPACT_RX, text)
    md = _count_matches(_MED_IMPACT_RX, text)
    if hi >= 1:
        return 4
    if md >= 2:
        return 3
    if md == 1:
        return 2
    return 1


def polarity_score(text: str) -> float:
    """
    Груба полярност: положителни - отрицателни
    => [-1.0, +1.0]
    """
    pos = _count_matches(_POS_RX, text)
    neg = _count_matches(_NEG_RX, text)
    if pos == neg == 0:
        return 0.0
    total = pos + neg
    return (pos - neg) / max(1, total)


def infer_trends(text: str, fallback_ccy: Iterable[str] = ("EUR", "USD")) -> Dict[str, Tuple[str, float]]:
    """
    Връща { "EUR": ("up"/"down"/"flat", pct_0_to_1), ... }
    Процес:
      1) Извличаме повлияни валути от ключови думи.
      2) Вземаме груба полярност от текста.
      3) Сила ~ |polarity| и наличието на high/med impact ключови думи.
    """
    t = (text or "").lower()
    ccys = extract_currencies(t)
    if not ccys:
        ccys = list(fallback_ccy)

    stars = importance_stars(t)
    pol = polarity_score(t)  # [-1..1]
    base = 0.3 + 0.2 * (stars - 1)  # 1★=0.3, 2★=0.5, 3★=0.7, 4★=0.9 (макс ще cap-нем)
    strength = min(1.0, max(0.1, base * (0.8 + 0.2 * abs(pol))))  # скалираме леко по полярност

    direction = "flat"
    if pol > 0.1:
        direction = "up"
    elif pol < -0.1:
        direction = "down"

    # правило: ако се споменават няколко CCY, първата получава основната посока,
    # втората - обратната (за типични кросове); останалите — слабо в посоката
    out: Dict[str, Tuple[str, float]] = {}
    if len(ccys) >= 2:
        out[ccys[0]] = (direction, strength)
        inv = "down" if direction == "up" else ("up" if direction == "down" else "flat")
        out[ccys[1]] = (inv, max(0.4, strength * 0.7))
        for c in ccys[2:]:
            out[c] = (direction, 0.4)
    else:
        out[ccys[0]] = (direction, strength)

    return out
