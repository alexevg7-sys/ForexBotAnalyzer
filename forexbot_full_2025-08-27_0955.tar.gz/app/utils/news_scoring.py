from __future__ import annotations

import html
import os
import re
from typing import Dict, Optional

import httpx

# ---------- Помощни ----------

_CYRILLIC_RE = re.compile(r"[а-яА-ЯЁёЀ-ӿ]")

def _looks_bg(s: str) -> bool:
    return bool(s and _CYRILLIC_RE.search(s))

def _deepl_translate(text: str, target_lang: str = "bg") -> Optional[str]:
    key = os.getenv("DEEPL_API_KEY", "").strip()
    if not key or not text:
        return None
    try:
        url = "https://api-free.deepl.com/v2/translate"
        r = httpx.post(url, data={"auth_key": key, "text": text, "target_lang": target_lang.upper()}, timeout=15.0)
        r.raise_for_status()
        j = r.json()
        return j["translations"][0]["text"]
    except Exception:
        return None

def _safe_translate(text: str, target_lang: str = "bg") -> str:
    """
    Мек превод: DeepL (ако има ключ) → deep_translator → googletrans → оригинала.
    Никога не хвърля изключение.
    """
    if not text:
        return text
    if target_lang == "bg" and _looks_bg(text):
        return text

    out = _deepl_translate(text, target_lang)
    if out:
        return out

    try:
        from deep_translator import GoogleTranslator
        return GoogleTranslator(source="auto", target=target_lang).translate(text)
    except Exception:
        pass

    try:
        from googletrans import Translator  # type: ignore
        tr = Translator()
        return tr.translate(text, dest=target_lang).text
    except Exception:
        pass

    return text

def _stars(n: int) -> str:
    n = max(0, min(5, int(n or 0)))
    return "★"*n + "☆"*(5-n)

def _arrow(d: str) -> str:
    return "↑" if (d or "").lower() == "up" else "↓"

def _fmt_trends(trends: Optional[Dict[str, list] | Dict[str, tuple]]) -> str:
    if not trends or not isinstance(trends, dict):
        return "—"
    out = []
    for k in ("EUR", "USD"):
        if k in trends:
            dir_, val = trends[k][0], trends[k][1]
            try:
                pct = int(val)
            except Exception:
                pct = 0
            out.append(f"{k}: {_arrow(dir_)} ({pct}%)")
    return " | ".join(out) if out else "—"

def _fmt_impacts(impacts) -> str:
    if not impacts:
        return "—"
    parts = []
    for it in impacts:
        try:
            cur = f"{it[0]}: {_arrow(str(it[1]))}"
            if len(it) > 2:
                cur += f" ({int(it[2])}%)"
            parts.append(cur)
        except Exception:
            continue
    return " | ".join(parts) if parts else "—"

def _esc(s: str) -> str:
    return html.escape(s or "")

# ---------- Основно API (СИНХРОННО!) ----------

def analyze_and_format(item: dict, target_lang: str = "bg", max_len: int = 3500) -> str:
    """
    Синхронно форматиране за Telegram (parse_mode=HTML safe).
    Поправя „късата“ новина и липсващия превод: превежда title/summary към BG ако са EN.
    Очаква item с ключове: title/summary/ts (+ по желание: stars/trends/impacts).
    """
    title = item.get("title_bg") or item.get("title") or ""
    summary = item.get("summary_bg") or item.get("summary") or item.get("description") or ""
    stars = item.get("stars", 0)
    trends = item.get("trends")
    impacts = item.get("impacts")
    ts = item.get("ts") or item.get("time") or ""

    # → Превод към BG (ако изглеждат EN)
    if target_lang.lower() == "bg":
        if title and not _looks_bg(title):
            title = _safe_translate(title, "bg")
        if summary and not _looks_bg(summary):
            summary = _safe_translate(summary, "bg")

    # Сглобяване (HTML-safe)
    out = []
    out.append(_esc(_stars(stars)))
    if title:
        out.append(f"<b>Заглавие:</b> {_esc(title)}")
    if summary:
        out.append(f"<b>Обобщение:</b> {_esc(summary)}")
    out.append(f"<b>Тренд:</b> {_esc(_fmt_trends(trends))}")
    out.append(f"<b>Влияние:</b> {_esc(_fmt_impacts(impacts))}")
    if ts:
        out.append(f"<i>{_esc(str(ts))}</i>")

    text = "\n".join(out)

    # Меко съкращаване при прекомерна дължина – режем само summary
    if len(text) > max_len and summary:
        keep = max_len - (len(text) - len(summary)) - 10
        if keep > 0:
            summary_cut = summary[:keep].rsplit(" ", 1)[0].rstrip(".,;:!?)…") + "…"
            out = []
            out.append(_esc(_stars(stars)))
            if title:
                out.append(f"<b>Заглавие:</b> {_esc(title)}")
            out.append(f"<b>Обобщение:</b> {_esc(summary_cut)}")
            out.append(f"<b>Тренд:</b> {_esc(_fmt_trends(trends))}")
            out.append(f"<b>Влияние:</b> {_esc(_fmt_impacts(impacts))}")
            if ts:
                out.append(f"<i>{_esc(str(ts))}</i>")
            text = "\n".join(out)

    return text
