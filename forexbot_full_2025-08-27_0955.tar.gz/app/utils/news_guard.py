from __future__ import annotations

import json
import os
import time
from typing import Dict, Tuple

from app.utils.logger import get_logger


class NewsGuard:
    """
    Чете JSONL файл с анализирани новини (scores.jsonl) и дава bias за валутна двойка.
    Скала: -2 .. +2 (използва се от енджина).
      + => в полза на BUY за базовата валута (AAA/BBB)
      - => в полза на SELL
    """
    def __init__(self, news_dir: str, recent_minutes: int = 60):
        self.news_dir = news_dir
        self.path = os.path.join(news_dir, "scores.jsonl")
        self.recent_seconds = max(10, int(recent_minutes)) * 60
        self.logger = get_logger("news.guard")

    def _read_recent(self) -> Dict[str, Dict[str, Tuple[str,int]]]:
        """
        Връща {id: {"trends": {"EUR":("up",30),"USD":("down",15)}, "ts": 1690000000}}
        Само записи от последните recent_seconds.
        """
        out: Dict[str, Dict] = {}
        now = int(time.time())
        if not os.path.exists(self.path):
            return out
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    rec = json.loads(line)
                    ts = int(rec.get("ts", 0))
                    if now - ts > self.recent_seconds:
                        continue
                    out[rec.get("id")] = {
                        "trends": rec.get("trends", {}),
                        "impacts": rec.get("impacts", []),
                        "ts": ts,
                        "stars": rec.get("stars", 1),
                        "title_bg": rec.get("title_bg", ""),
                    }
        except Exception:
            pass
        return out

    def bias_for_pair(self, pair: str) -> Tuple[int, str]:
        """
        Връща (bias, comment), където bias ∈ {-2,-1,0,1,2}.
        comment показва последните влияния за двете валути.
        """
        data = self._read_recent()
        if not data:
            return 0, ""

        pair = pair.replace("_","/").upper()
        if "/" not in pair:
            return 0, ""
        base, quote = pair.split("/", 1)

        # акумулирай по валута: up=+pct, down=-pct
        agg: Dict[str, int] = {}
        for rec in data.values():
            for cur, t in rec.get("trends", {}).items():
                if not isinstance(t, (list, tuple)) or len(t) != 2:
                    continue
                d, p = t
                val = int(p) * (1 if (d == "up") else -1)
                agg[cur] = agg.get(cur, 0) + val

            # impacts (добави още малко тежест)
            for item in rec.get("impacts", []):
                if not isinstance(item, (list, tuple)) or len(item) != 3:
                    continue
                cur, d, p = item
                val = int(p) * (1 if (d == "up") else -1)
                agg[cur] = agg.get(cur, 0) + val//2

        base_score = agg.get(base, 0)
        quote_score = agg.get(quote, 0)
        net = base_score - quote_score

        # картирай -> -2..2
        bias = 0
        if net >= 120: bias = 2
        elif net >= 60: bias = 1
        elif net <= -120: bias = -2
        elif net <= -60: bias = -1

        sign = lambda x: f"+{x}" if x >= 0 else str(x)
        comment = f"Новини {base} {sign(base_score)} / {quote} {sign(quote_score)} (посл. {self.recent_seconds//60}м)"
        return bias, comment
