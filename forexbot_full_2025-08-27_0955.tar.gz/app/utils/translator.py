from __future__ import annotations

import re
from typing import Iterable, List, Optional

_MAX_CHUNK = 3500  # безопасно за повечето уеб преводачи

def _soft_split(text: str, limit: int = _MAX_CHUNK) -> List[str]:
    if not text:
        return [""]
    if len(text) <= limit:
        return [text]

    out: List[str] = []
    remaining = text
    while remaining:
        if len(remaining) <= limit:
            out.append(remaining)
            break
        cut = remaining.rfind("\n\n", 0, limit)
        if cut == -1:
            cut = remaining.rfind("\n", 0, limit)
        if cut == -1:
            cut = limit
        out.append(remaining[:cut].rstrip())
        remaining = remaining[cut:].lstrip()
    return [p for p in out if p]

def _normalize_ws(s: str) -> str:
    s = re.sub(r"[ \t]+", " ", s)
    s = re.sub(r"\s+\n", "\n", s)
    s = re.sub(r"\n{3,}", "\n\n", s)
    return s.strip()

def translate_text(text: str, to_lang: str = "bg", from_lang: str = "auto") -> str:
    """
    Опит за превод с няколко backend-а; ако нищо не работи -> връща оригинала.
    Няма нужда от API ключове.
    """
    if not text or to_lang is None:
        return text or ""

    chunks = _soft_split(text, _MAX_CHUNK)
    translated: List[str] = []

    # 1) deep_translator.GoogleTranslator (ако е наличен)
    try:
        from deep_translator import GoogleTranslator  # type: ignore
        for ch in chunks:
            translated.append(GoogleTranslator(source=from_lang, target=to_lang).translate(ch))
        return _normalize_ws("\n\n".join(translated))
    except Exception:
        translated.clear()

    # 2) argos-translate (локален офлайн, ако е наличен и зареден пакет)
    try:
        import argostranslate.package, argostranslate.translate  # type: ignore
        for ch in chunks:
            translated.append(argostranslate.translate.translate(ch, from_lang, to_lang))
        return _normalize_ws("\n\n".join(translated))
    except Exception:
        translated.clear()

    # fallback
    return _normalize_ws(text)
