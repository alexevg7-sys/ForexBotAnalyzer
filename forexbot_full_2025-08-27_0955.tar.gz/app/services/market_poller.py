from __future__ import annotations

import asyncio
from typing import Iterable, List

from app.utils.logger import get_logger
from app.services.market_cache import MarketCache
from app.data_providers.twelvedata_client import TwelveDataClient


class MarketPoller:
    """
    Циклично дърпа OHLC от TwelveData и кешира за H1/M15/H4.
    """
    def __init__(self, td: TwelveDataClient, cache: MarketCache, pairs: Iterable[str],
                 tf_h1: str, tf_m15: str, tf_h4: str, poll_interval_seconds: int, outputsize: int = 120):
        self.td = td
        self.cache = cache
        self.pairs: List[str] = list(pairs)
        self.tf_h1 = tf_h1
        self.tf_m15 = tf_m15
        self.tf_h4 = tf_h4
        self.interval = max(15, int(poll_interval_seconds))
        self.outputsize = int(outputsize)
        self.logger = get_logger("market.poller")
        self._i = 0

    async def _pull_one(self, pair: str):
        # дърпаме и трите таймфрейма; всяка грешка логваме с traceback
        try:
            df15 = await self.td.fetch_ohlc(pair, self.tf_m15, outputsize=self.outputsize)
            if df15 is not None and not df15.empty:
                self.cache.save(pair, self.tf_m15, df15)
        except Exception:
            self.logger.exception("market:fetch:m15", extra={"pair": pair})

        try:
            df1h = await self.td.fetch_ohlc(pair, self.tf_h1, outputsize=self.outputsize)
            if df1h is not None and not df1h.empty:
                self.cache.save(pair, self.tf_h1, df1h)
        except Exception:
            self.logger.exception("market:fetch:h1", extra={"pair": pair})

        try:
            df4h = await self.td.fetch_ohlc(pair, self.tf_h4, outputsize=self.outputsize)
            if df4h is not None and not df4h.empty:
                self.cache.save(pair, self.tf_h4, df4h)
        except Exception:
            self.logger.exception("market:fetch:h4", extra={"pair": pair})

    async def run_forever(self):
        self.logger.info("market:start", extra={"interval": self.interval})
        while True:
            try:
                pair = self.pairs[self._i % len(self.pairs)]
                self._i += 1
                await self._pull_one(pair)
            except Exception:
                self.logger.exception("market:error")
            await asyncio.sleep(self.interval)
