from __future__ import annotations

import asyncio
import os

from app.strategies.signal_engine import SignalEngine
from app.telegram_bot.bot import Notifier
from app.telegram_bot.formatting import format_signal_message
from app.utils.news_guard import NewsGuard
from app.utils.logger import get_logger
from app.services.control import Control


class SignalScheduler:
    """
    Обхожда двойките и се опитва да генерира H1 сигнал.
    Уважава /signals, /risk, /confidence, /smc, /smcstrict и /config (SMC параметри).
    """
    def __init__(self, data_dir: str, state_dir: str, pairs, notifier: Notifier, min_confidence: int, rr_base: float, interval_seconds: int = 20, control: Control | None = None):
        self.engine = SignalEngine(data_dir=data_dir, state_dir=state_dir, min_confidence=min_confidence, rr_base=rr_base)
        self.guard = NewsGuard(news_dir=os.path.join(data_dir, "news"), recent_minutes=60)
        self._pairs_initial = list(pairs)
        self.notifier = notifier
        self.interval = max(10, int(interval_seconds))
        self.logger = get_logger("signals.scheduler")
        self._control = control
        self._idx = 0

    async def run_forever(self):
        self.logger.info("signals:start", extra={"interval_s": self.interval})
        while True:
            try:
                if self._control:
                    if not await self._control.signals_enabled():
                        await asyncio.sleep(self.interval); continue
                    rr = await self._control.get_rr()
                    mc = await self._control.get_min_conf()
                    smc_en = await self._control.smc_enabled()
                    smc_strict = await self._control.smc_strict()
                    smc_params = await self._control.smc_params()
                    self.engine.update_params(min_confidence=mc, rr_base=rr, smc_enabled=smc_en, smc_strict=smc_strict, smc_params=smc_params)
                    pairs = await self._control.get_pairs()
                    if not pairs:
                        pairs = self._pairs_initial
                else:
                    pairs = self._pairs_initial

                pair = pairs[self._idx % len(pairs)]
                self._idx += 1

                bias, comment = self.guard.bias_for_pair(pair)
                sig = self.engine.evaluate(pair, news_bias=bias)
                if sig:
                    if comment and bias != 0:
                        sig.context = (sig.context or "") + f" | {comment}"
                    msg = format_signal_message(sig)
                    await self.notifier.send_text(msg)
            except Exception as e:
                self.logger.error("signals:error", extra={"err": str(e)})
            await asyncio.sleep(self.interval)
