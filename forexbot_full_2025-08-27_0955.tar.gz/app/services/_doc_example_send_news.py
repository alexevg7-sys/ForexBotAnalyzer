# пример: адаптирай мястото си за изпращане на новина
from app.utils.news_scoring import analyze_and_format
from app.telegram.notifier import send_broadcast
import os

def send_news_item(news_item: dict):
    msg = analyze_and_format(news_item, target_lang="bg", max_len=3500)  # HTML-safe
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
    targets = os.environ.get("TELEGRAM_TARGET_CHAT_ID", "")
    if token and targets:
        send_broadcast(token, targets, msg, parse_mode="HTML")
