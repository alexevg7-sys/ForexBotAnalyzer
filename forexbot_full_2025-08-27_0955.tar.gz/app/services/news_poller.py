from __future__ import annotations

import asyncio
import json
import os
from typing import List, Dict, Any

from app.utils.logger import get_logger
from app.telegram_bot.bot import Notifier
from app.services.control import Control
from app.data_providers.finnhub_client import FinnhubClient
from app.data_providers.deepl_client import DeepLClient
from app.utils.news_scoring import analyze_and_format, render_telegram_message, NewsAnalysis


class NewsPoller:
    def __init__(self, state_dir: str, data_dir: str, finnhub: FinnhubClient, deepl: DeepLClient, notifier: Notifier, refresh_seconds: int = 60, control: Control | None = None):
        self.state_dir = state_dir
        self.data_dir = data_dir
        self.finnhub = finnhub
        self.deepl = deepl
        self.notifier = notifier
        self.refresh = max(20, int(refresh_seconds))
        self._control = control
        self.logger = get_logger("news.poller")
        self.ids_path = os.path.join(state_dir, "news_ids.json")
        self.scores_path = os.path.join(data_dir, "news", "scores.jsonl")
        os.makedirs(os.path.dirname(self.scores_path), exist_ok=True)
        self.ids = self._load_ids()

    def _load_ids(self) -> Dict[str, int]:
        if os.path.exists(self.ids_path):
            try:
                with open(self.ids_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return {}
        return {}

    def _save_ids(self):
        try:
            with open(self.ids_path, "w", encoding="utf-8") as f:
                json.dump(self.ids, f)
        except Exception:
            pass

    async def run_forever(self):
        self.logger.info("news:start", extra={"refresh": self.refresh})
        while True:
            try:
                if self._control and not await self._control.news_enabled():
                    await asyncio.sleep(self.refresh); continue

                items = await self.finnhub.fetch_forex_news()
                if not items:
                    await asyncio.sleep(self.refresh); continue

                new_count = 0
                for itm in items:
                    title = itm.get("headline") or ""
                    summary = itm.get("summary") or ""
                    ts_unix = int(itm.get("datetime") or 0)
                    if not title or not ts_unix:  # безопасност
                        continue

                    nid = f"{title.strip().lower()}::{ts_unix}"
                    if nid in self.ids:
                        continue
                    self.ids[nid] = 1

                    na: NewsAnalysis = analyze_and_format(
                        title_en=title,
                        summary_en=summary,
                        ts_unix=ts_unix,
                        translator=self.deepl,
                    )

                    try:
                        with open(self.scores_path, "a", encoding="utf-8") as f:
                            rec = {
                                "id": na.id, "ts": na.ts, "stars": na.stars,
                                "trends": na.trends, "impacts": na.impacts,
                                "title_bg": na.title_bg,
                            }
                            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
                    except Exception:
                        self.logger.exception("news:write_score:error")

                    if not (self._control and await self._control.silent_mode()):
                        msg = render_telegram_message(na)
                        await self.notifier.send_text(msg)

                    new_count += 1

                if new_count:
                    self._save_ids()

            except Exception:
                # покажи целия traceback
                self.logger.exception("news:error")

            await asyncio.sleep(self.refresh)
