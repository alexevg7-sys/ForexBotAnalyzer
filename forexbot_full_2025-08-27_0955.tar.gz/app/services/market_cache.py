from __future__ import annotations

import os
import logging
from typing import Optional, Dict
import pandas as pd

LOG = logging.getLogger("market_cache")
LOG.setLevel(logging.INFO)

class MarketCache:
    """
    Отговаря за четене/сливане/ретенция и запис на OHLC CSV файлове.
    """
    def __init__(self, base_dir: str = "/OPT/forexbot/data", retention_days: int = 7):
        self.base = base_dir
        self.retention_days = int(retention_days)
        # основна директория + подпапка за ohlc
        self.ohlc_dir = os.path.join(self.base, "ohlc")
        os.makedirs(self.ohlc_dir, exist_ok=True)

    # -------- helpers --------
    @staticmethod
    def _safe_pair(pair: str) -> str:
        # EUR/USD -> EUR_USD
        return pair.replace("/", "_").replace(" ", "")

    def _path(self, pair: str, tf: str) -> str:
        return os.path.join(self.ohlc_dir, f"{self._safe_pair(pair)}_{tf}.csv")

    @staticmethod
    def _to_utc_series(s: pd.Series) -> pd.Series:
        # Превръща към pandas datetime и добавя tz=UTC (било то naive или вече tz-aware)
        s = pd.to_datetime(s, errors="coerce", utc=True)
        return s

    def _cutoff(self) -> pd.Timestamp:
        # tz-aware UTC timestamp
        return pd.Timestamp.now(tz="UTC") - pd.Timedelta(days=self.retention_days)

    # -------- API --------
    def save(self, pair: str, tf: str, df_new: Optional[pd.DataFrame]) -> None:
        """
        Слива новите данни към кеша, прави дедупликация, ретенция и запис.
        Очаква колонa 'datetime' + open/high/low/close (+ по избор 'volume').
        """
        if df_new is None or len(df_new) == 0:
            return

        df_new = df_new.copy()

        # Нормализирай времето -> tz-aware UTC
        if "datetime" not in df_new.columns:
            LOG.warning("No 'datetime' column for %s %s; skip.", pair, tf)
            return
        df_new["datetime"] = self._to_utc_series(df_new["datetime"])

        # Ограничи до ретенцията
        cutoff = self._cutoff()
        df_new = df_new[df_new["datetime"] >= cutoff]

        # Подреди колоните безопасно (някои провайдъри нямат 'volume')
        cols_order = [c for c in ["datetime", "open", "high", "low", "close", "volume"] if c in df_new.columns]
        df_new = df_new[cols_order]

        path = self._path(pair, tf)
        os.makedirs(os.path.dirname(path), exist_ok=True)

        # Чети старото, ако има
        if os.path.exists(path):
            df_old = pd.read_csv(path, parse_dates=["datetime"])
            if len(df_old):
                df_old["datetime"] = self._to_utc_series(df_old["datetime"])
                # Хомогенизирай колоните
                df_old = df_old[[c for c in cols_order if c in df_old.columns]]
                df = pd.concat([df_old, df_new], ignore_index=True)
            else:
                df = df_new
        else:
            df = df_new

        # Дедупликация и финална ретенция
        df = df.drop_duplicates(subset=["datetime"]).sort_values("datetime")
        df = df[df["datetime"] >= cutoff]

        # Запис
        df.to_csv(path, index=False)
        LOG.info("cache.save: %s %s -> %s rows (cutoff=%s)", pair, tf, len(df), cutoff.isoformat())

