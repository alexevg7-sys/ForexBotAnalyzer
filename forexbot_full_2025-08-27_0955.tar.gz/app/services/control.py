from __future__ import annotations

import asyncio
import json
import os
from dataclasses import dataclass, asdict
from typing import List, Dict, Any


@dataclass
class ControlState:
    signals_enabled: bool
    news_enabled: bool
    signal_min_confidence: int
    risk_rr_base: float
    pairs_active: List[str]
    silent_mode: bool = False
    smc_enabled: bool = True
    smc_strict: bool = False
    # --- SMC tunables ---
    smc_swing_len: int = 50
    smc_internal_len: int = 5
    smc_ob_len: int = 5
    smc_mitigation: str = "wick"  # wick|close
    smc_eq_thresh_atr: float = 0.10
    smc_fvg_width_atr_mult: float = 0.0


class ControlStore:
    def __init__(self, path: str):
        self.path = path
        os.makedirs(os.path.dirname(path), exist_ok=True)

    def load(self, defaults: ControlState) -> ControlState:
        if os.path.exists(self.path):
            try:
                with open(self.path, "r", encoding="utf-8") as f:
                    raw = json.load(f)
                return ControlState(
                    signals_enabled=bool(raw.get("signals_enabled", defaults.signals_enabled)),
                    news_enabled=bool(raw.get("news_enabled", defaults.news_enabled)),
                    signal_min_confidence=int(raw.get("signal_min_confidence", defaults.signal_min_confidence)),
                    risk_rr_base=float(raw.get("risk_rr_base", defaults.risk_rr_base)),
                    pairs_active=list(raw.get("pairs_active", defaults.pairs_active)),
                    silent_mode=bool(raw.get("silent_mode", defaults.silent_mode)),
                    smc_enabled=bool(raw.get("smc_enabled", defaults.smc_enabled)),
                    smc_strict=bool(raw.get("smc_strict", defaults.smc_strict)),
                    smc_swing_len=int(raw.get("smc_swing_len", defaults.smc_swing_len)),
                    smc_internal_len=int(raw.get("smc_internal_len", defaults.smc_internal_len)),
                    smc_ob_len=int(raw.get("smc_ob_len", defaults.smc_ob_len)),
                    smc_mitigation=str(raw.get("smc_mitigation", defaults.smc_mitigation)),
                    smc_eq_thresh_atr=float(raw.get("smc_eq_thresh_atr", defaults.smc_eq_thresh_atr)),
                    smc_fvg_width_atr_mult=float(raw.get("smc_fvg_width_atr_mult", defaults.smc_fvg_width_atr_mult)),
                )
            except Exception:
                pass
        self.save(defaults)
        return defaults

    def save(self, state: ControlState) -> None:
        try:
            with open(self.path, "w", encoding="utf-8") as f:
                json.dump(asdict(state), f, ensure_ascii=False, indent=0)
        except Exception:
            pass


class Control:
    def __init__(self, store: ControlStore, defaults: ControlState):
        self._store = store
        self._lock = asyncio.Lock()
        self._state = self._store.load(defaults)

    # ----- getters -----
    async def get_state(self) -> ControlState:
        async with self._lock:
            return self._state

    async def signals_enabled(self) -> bool:
        async with self._lock:
            return self._state.signals_enabled

    async def news_enabled(self) -> bool:
        async with self._lock:
            return self._state.news_enabled

    async def get_rr(self) -> float:
        async with self._lock:
            return self._state.risk_rr_base

    async def get_min_conf(self) -> int:
        async with self._lock:
            return self._state.signal_min_confidence

    async def get_pairs(self) -> List[str]:
        async with self._lock:
            return list(self._state.pairs_active)

    async def silent_mode(self) -> bool:
        async with self._lock:
            return self._state.silent_mode

    async def smc_enabled(self) -> bool:
        async with self._lock:
            return self._state.smc_enabled

    async def smc_strict(self) -> bool:
        async with self._lock:
            return self._state.smc_strict

    async def smc_params(self) -> Dict[str, Any]:
        async with self._lock:
            return dict(
                swing_len=self._state.smc_swing_len,
                internal_len=self._state.smc_internal_len,
                ob_len=self._state.smc_ob_len,
                ob_mitigation=self._state.smc_mitigation,
                eq_thresh_atr=self._state.smc_eq_thresh_atr,
                fvg_width_atr_mult=self._state.smc_fvg_width_atr_mult,
            )

    # ----- setters -----
    async def set_signals(self, enabled: bool):
        async with self._lock:
            self._state.signals_enabled = bool(enabled)
            self._store.save(self._state)

    async def set_news(self, enabled: bool):
        async with self._lock:
            self._state.news_enabled = bool(enabled)
            self._store.save(self._state)

    async def set_rr(self, rr: float):
        async with self._lock:
            self._state.risk_rr_base = float(rr)
            self._store.save(self._state)

    async def set_min_conf(self, val: int):
        async with self._lock:
            self._state.signal_min_confidence = int(val)
            self._store.save(self._state)

    async def set_pairs(self, pairs: List[str]):
        async with self._lock:
            self._state.pairs_active = [p.upper().replace(" ", "") for p in pairs if p]
            self._store.save(self._state)

    async def add_pair(self, pair: str):
        async with self._lock:
            p = pair.upper().replace(" ", "")
            if p not in self._state.pairs_active:
                self._state.pairs_active.append(p)
                self._store.save(self._state)

    async def remove_pair(self, pair: str):
        async with self._lock:
            p = pair.upper().replace(" ", "")
            self._state.pairs_active = [x for x in self._state.pairs_active if x != p]
            self._store.save(self._state)

    async def set_silent(self, enabled: bool):
        async with self._lock:
            self._state.silent_mode = bool(enabled)
            self._store.save(self._state)

    async def set_smc(self, enabled: bool):
        async with self._lock:
            self._state.smc_enabled = bool(enabled)
            self._store.save(self._state)

    async def set_smc_strict(self, enabled: bool):
        async with self._lock:
            self._state.smc_strict = bool(enabled)
            self._store.save(self._state)

    # --- individual SMC param setters with validation ---
    async def set_smc_param(self, key: str, value):
        async with self._lock:
            if key == "swing_len":
                v = int(value); v = max(10, min(200, v)); self._state.smc_swing_len = v
            elif key == "internal_len":
                v = int(value); v = max(2, min(20, v)); self._state.smc_internal_len = v
            elif key == "ob_len":
                v = int(value); v = max(2, min(20, v)); self._state.smc_ob_len = v
            elif key == "mitigation":
                v = str(value).lower()
                if v not in {"wick","close"}: v = "wick"
                self._state.smc_mitigation = v
            elif key == "eq_thresh":
                v = float(value); v = max(0.0, min(0.5, v)); self._state.smc_eq_thresh_atr = v
            elif key == "fvg_width":
                v = float(value); v = max(0.0, min(2.0, v)); self._state.smc_fvg_width_atr_mult = v
            else:
                raise ValueError("Unknown parameter")
            self._store.save(self._state)
