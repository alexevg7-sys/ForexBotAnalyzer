from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, List

import pandas as pd
import numpy as np

from app.strategies.indicators import ema, macd, rsi, atr, candle_strength, swing_points
from app.strategies.smc_lux import analyze_smc_lux, smc_bonus_and_conflict_lux
from app.strategies.scoring import ScoreContext, to_confidence
from app.data_providers.twelvedata_client import normalize_interval
from app.utils.forex import pip_info, round_price


@dataclass
class BTParams:
    rr_base: float
    min_conf: int
    smc_enabled: bool
    smc_strict: bool
    smc_params: Dict[str, object]


def _csv(data_dir: str, interval: str, pair: str) -> str:
    iv = normalize_interval(interval)
    fname = pair.replace("/", "_")
    return f"{data_dir}/candles/{iv}/{fname}.csv"


def _load_df(path: str) -> Optional[pd.DataFrame]:
    try:
        df = pd.read_csv(path)
        if df.empty or "close" not in df: return None
        df["datetime"] = pd.to_datetime(df["datetime"]); df.set_index("datetime", inplace=True)
        return df
    except Exception:
        return None


def _eval_signal_at(h1: pd.DataFrame, m15: pd.DataFrame, h4: pd.DataFrame, idx: int, bt: BTParams, pair: str):
    """Реплика на енджина, но „as-of“ към индекс idx (H1)."""
    if idx < 60 or idx >= len(h1): return None

    h4c = h4.iloc[:len(h4)]  # целият H4 (не режем)
    if len(h4c) < 60: return None
    h4c = h4c.copy()
    h4c["ema200"] = ema(h4c["close"], 200); h4c["ema_slope"] = h4c["ema200"].diff()
    h4_last = h4c.iloc[-1]
    h4_trend = "up" if h4_last["close"] > h4_last["ema200"] and h4_last["ema_slope"] > 0 else ("down" if h4_last["close"] < h4_last["ema200"] and h4_last["ema_slope"] < 0 else "flat")

    h1c = h1.iloc[:idx+1].copy()
    h1c["ema50"] = ema(h1c["close"], 50)
    h1c["ema50_prev"] = h1c["ema50"].shift(1)
    h1c["close_prev"] = h1c["close"].shift(1)
    _, _, hist = macd(h1c["close"])
    h1c["macd_hist"] = hist
    h1c["candle_pow"] = candle_strength(h1c["open"], h1c["close"], h1c["high"], h1c["low"])
    h1c["atr14"] = atr(h1c["high"], h1c["low"], h1c["close"], 14)

    last = h1c.iloc[-1]; prev = h1c.iloc[-2]
    buy_cross = prev["close_prev"] <= prev["ema50_prev"] and last["close"] > last["ema50"]
    sell_cross = prev["close_prev"] >= prev["ema50_prev"] and last["close"] < last["ema50"]

    dir_sig = "BUY" if (buy_cross and last["macd_hist"] > 0) else ("SELL" if (sell_cross and last["macd_hist"] < 0) else None)
    if not dir_sig: return None

    m15c = m15.iloc[:min(len(m15), (idx+1)*4)].copy()  # грубо: 4* M15 в H1
    m15c["rsi"] = rsi(m15c["close"], 14); m15_last = m15c.iloc[-1]
    rsi_conf = 1 if (dir_sig == "BUY" and m15_last["rsi"] >= 50) or (dir_sig == "SELL" and m15_last["rsi"] <= 50) else (-1 if (dir_sig == "BUY" and m15_last["rsi"] < 45) or (dir_sig == "SELL" and m15_last["rsi"] > 55) else 0)

    sh_i, sh, sl_i, sl = swing_points(h1c["high"], h1c["low"], left=3, right=3)
    structure_break = 0
    if dir_sig == "BUY" and sh is not None: structure_break = 1 if last["close"] > sh else 0
    if dir_sig == "SELL" and sl is not None: structure_break = 1 if last["close"] < sl else 0

    trend_align = 1 if (h4_trend == "up" and dir_sig == "BUY") or (h4_trend == "down" and dir_sig == "SELL") else (-1 if h4_trend in ("up", "down") else 0)
    macd_strength = float(abs(last["macd_hist"])) / float(h1c["close"].iloc[-100:].std() + 1e-8); macd_strength = max(0.0, min(1.0, macd_strength))
    candle_pow = float(last["candle_pow"])

    extra_bonus = 0
    if bt.smc_enabled:
        p = bt.smc_params
        smc = analyze_smc_lux(
            h1c,
            swing_len=int(p.get("swing_len", 50)),
            internal_len=int(p.get("internal_len", 5)),
            ob_len=int(p.get("ob_len", 5)),
            ob_mitigation=str(p.get("ob_mitigation", "wick")),
            eq_thresh_atr=float(p.get("eq_thresh_atr", 0.10)),
            fvg_width_atr_mult=float(p.get("fvg_width_atr_mult", 0.0)),
        )
        bonus, conflict, _ = smc_bonus_and_conflict_lux(smc, dir_sig)
        if bt.smc_strict and conflict:
            return None
        extra_bonus = bonus

    ctx = ScoreContext(
        trend_align=trend_align, macd_strength=macd_strength, rsi_confirm=rsi_conf,
        candle_power=candle_pow, structure_break=structure_break, news_bias=0,
        extra_bonus=extra_bonus
    )
    conf = to_confidence(ctx)
    if conf < bt.min_conf: return None

    entry = float(last["close"]); atr14 = float(h1c["atr14"].iloc[-1])
    if dir_sig == "BUY":
        sl_candidate = min(sl if sl is not None else entry, entry - 1.2 * atr14)
        slp = min(sl_candidate, entry - 0.6 * atr14); risk = entry - slp
        tp1 = entry + risk * 1.0; tp2 = entry + risk * bt.rr_base
    else:
        sh_val = sh if sh is not None else entry
        sl_candidate = max(sh_val, entry + 1.2 * atr14)
        slp = max(sl_candidate, entry + 0.6 * atr14); risk = slp - entry
        tp1 = entry - risk * 1.0; tp2 = entry - risk * bt.rr_base

    return dict(
        idx=idx, dir=dir_sig, entry=entry, sl=slp, tp1=tp1, tp2=tp2, conf=int(conf)
    )


def _simulate_outcome(h1: pd.DataFrame, signal: dict) -> str:
    """Симулация: сканираме следващите H1 барове за TP2/TP1/SL (приближение)."""
    i0 = signal["idx"]; direction = signal["dir"]; sl = signal["sl"]; tp1 = signal["tp1"]; tp2 = signal["tp2"]
    MAX_HOLD = 72  # до 3 дни
    for k in range(i0+1, min(len(h1), i0+1+MAX_HOLD)):
        bar = h1.iloc[k]
        if direction == "BUY":
            hit_sl = bar["low"] <= sl
            hit_tp2 = bar["high"] >= tp2
            hit_tp1 = bar["high"] >= tp1
            if hit_sl: return "SL"
            if hit_tp2: return "TP2"
            if hit_tp1: return "TP1"
        else:
            hit_sl = bar["high"] >= sl
            hit_tp2 = bar["low"] <= tp2
            hit_tp1 = bar["low"] <= tp1
            if hit_sl: return "SL"
            if hit_tp2: return "TP2"
            if hit_tp1: return "TP1"
    return "TIMEOUT"


def run_backtest(*, data_dir: str, pair: str, bars: int, rr_base: float, min_conf: int,
                 smc_enabled: bool, smc_strict: bool, smc_params: Dict[str, object]) -> str:
    path_h1 = _csv(data_dir, "1h", pair)
    path_m15 = _csv(data_dir, "15min", pair)
    path_h4 = _csv(data_dir, "4h", pair)
    h1 = _load_df(path_h1); m15 = _load_df(path_m15); h4 = _load_df(path_h4)
    if h1 is None or m15 is None or h4 is None:
        return f"❌ Няма достатъчно данни за {pair} (очаквам H1/M15/H4 кеш CSV)."

    h1 = h1.tail(bars + 120)  # малко предистория за индикатори
    bt = BTParams(rr_base=rr_base, min_conf=min_conf, smc_enabled=smc_enabled, smc_strict=smc_strict, smc_params=smc_params)

    signals: List[dict] = []
    for i in range(len(h1)-1):
        sig = _eval_signal_at(h1, m15, h4, i, bt, pair)
        if sig:
            # анти-дупликат на H1 бар/посока
            if not signals or (signals and (signals[-1]["idx"] != sig["idx"] or signals[-1]["dir"] != sig["dir"])):
                signals.append(sig)

    if not signals:
        return f"ℹ️ Бектест {pair}: 0 сигнала в последните {bars} H1 бара при текущите филтри."

    outcomes = []
    for s in signals:
        res = _simulate_outcome(h1, s)
        outcomes.append(res)

    n = len(signals)
    tp2 = outcomes.count("TP2")
    tp1 = outcomes.count("TP1")
    sl = outcomes.count("SL")
    to = outcomes.count("TIMEOUT")

    # expectancy по RR (TP1=+1R, TP2=+rr_base R, SL=-1R, TIMEOUT=0R)
    exp_r = (tp1 * 1.0 + tp2 * rr_base - sl * 1.0) / max(1, n)

    # кратък листинг на първите 5 сделки
    preview = []
    for s, r in list(zip(signals, outcomes))[:5]:
        preview.append(f"{s['dir']} @{s['entry']:.5f} SL {s['sl']:.5f} TP1 {s['tp1']:.5f} TP2 {s['tp2']:.5f} | conf {s['conf']} | {r}")

    msg = (
        f"📈 Бектест {pair} (H1) — последни {bars} бара\n"
        f"Сигнали: <b>{n}</b> | TP2: <b>{tp2}</b> | TP1: <b>{tp1}</b> | SL: <b>{sl}</b> | TIMEOUT: <b>{to}</b>\n"
        f"Очаквана стойност (R): <b>{exp_r:.2f}</b> при RR2={rr_base:.2f}, MinConf={min_conf}%\n"
        f"SMC: {'ON' if smc_enabled else 'OFF'} {'[Strict]' if smc_strict else ''} | cfg: "
        f"swing={bt.smc_params.get('swing_len')}, int={bt.smc_params.get('internal_len')}, ob_len={bt.smc_params.get('ob_len')}, "
        f"mit={bt.smc_params.get('ob_mitigation')}, eq={bt.smc_params.get('eq_thresh_atr')}, fvgw={bt.smc_params.get('fvg_width_atr_mult')}\n\n"
        + "\n".join(preview)
    )
    return msg
