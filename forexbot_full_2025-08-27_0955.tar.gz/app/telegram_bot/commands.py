from __future__ import annotations

import asyncio
from typing import List

from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes
from telegram.constants import ParseMode

from app.services.control import Control
from app.utils.logger import get_logger


logger = get_logger("tg.commands")


def _auth_ok(update: Update, allowed_chat_ids: List[int]) -> bool:
    chat_id = update.effective_chat.id if update.effective_chat else None
    return chat_id in allowed_chat_ids


def register_commands(app: Application, control: Control, allowed_chat_ids: List[int]):
    async def _reply(update: Update, text: str):
        try:
            await update.effective_message.reply_text(text, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
        except Exception as e:
            logger.error("reply:error", extra={"err": str(e)})

    async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not _auth_ok(update, allowed_chat_ids): return
        msg = (
            "<b>Команди</b>\n"
            "/status – подробен статус\n"
            "/signals on|off – включи/спри сигналите\n"
            "/news on|off – включи/спри новините\n"
            "/risk <0.5..5.0> – RR за TP2 (TP1=1.0)\n"
            "/confidence <50..95> – минимална увереност за сигнал\n"
            "/pairs list|add <AAA/BBB>|remove <AAA/BBB>\n"
            "/smc on|off – Smart Money слой\n"
            "/smcstrict on|off – конфликт с SMC блокира сигнала\n"
            "/config show | /config set <key> <value>\n"
            "   keys: swing_len(10..200), internal_len(2..20), ob_len(2..20), mitigation(wick|close),\n"
            "         eq_thresh(0..0.5), fvg_width(0..2.0)\n"
            "/backtest <PAIR> [bars=1000] – H1 бектест върху кеша\n"
            "/silent on|off – тих режим\n"
            "/help – тази помощ\n"
        )
        await _reply(update, msg)

    async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not _auth_ok(update, allowed_chat_ids): return
        st = await control.get_state()
        pairs_preview = ", ".join(st.pairs_active[:8]); more = "" if len(st.pairs_active) <= 8 else f" …(+{len(st.pairs_active)-8})"
        msg = (
            f"<b>Статус</b>\n"
            f"Signals: <b>{'ON' if st.signals_enabled else 'OFF'}</b>\n"
            f"News: <b>{'ON' if st.news_enabled else 'OFF'}</b>\n"
            f"Min confidence: <b>{st.signal_min_confidence}%</b>\n"
            f"RR base (TP2): <b>{st.risk_rr_base:.2f}</b>\n"
            f"SMC: <b>{'ON' if st.smc_enabled else 'OFF'}</b> / Strict: <b>{'ON' if st.smc_strict else 'OFF'}</b>\n"
            f"SMC cfg: swing={st.smc_swing_len}, internal={st.smc_internal_len}, ob_len={st.smc_ob_len}, mit={st.smc_mitigation}, eq={st.smc_eq_thresh_atr:.2f}, fvgw={st.smc_fvg_width_atr_mult:.2f}\n"
            f"Pairs ({len(st.pairs_active)}): {pairs_preview}{more}\n"
            f"Silent: <b>{'ON' if st.silent_mode else 'OFF'}</b>"
        )
        await _reply(update, msg)

    async def cmd_signals(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not _auth_ok(update, allowed_chat_ids): return
        arg = (context.args[0].lower() if context.args else "")
        if arg not in {"on", "off"}: return await _reply(update, "Използване: <code>/signals on</code> или <code>/signals off</code>")
        await control.set_signals(arg == "on"); await _reply(update, f"Сигналите: <b>{'ON' if arg=='on' else 'OFF'}</b>")

    async def cmd_news(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not _auth_ok(update, allowed_chat_ids): return
        arg = (context.args[0].lower() if context.args else "")
        if arg not in {"on", "off"}: return await _reply(update, "Използване: <code>/news on</code> или <code>/news off</code>")
        await control.set_news(arg == "on"); await _reply(update, f"Новините: <b>{'ON' if arg=='on' else 'OFF'}</b>")

    async def cmd_risk(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not _auth_ok(update, allowed_chat_ids): return
        if not context.args: return await _reply(update, "Използване: <code>/risk 1.5</code> (0.5..5.0)")
        try: rr = float(context.args[0])
        except Exception: return await _reply(update, "Невалидно число. Пример: <code>/risk 2.0</code>")
        rr = min(5.0, max(0.5, rr)); await control.set_rr(rr); await _reply(update, f"RR базово (TP2): <b>{rr:.2f}</b>")

    async def cmd_confidence(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not _auth_ok(update, allowed_chat_ids): return
        if not context.args: return await _reply(update, "Използване: <code>/confidence 70</code> (50..95)")
        try: v = int(context.args[0])
        except Exception: return await _reply(update, "Невалидна стойност. Пример: <code>/confidence 75</code>")
        v = min(95, max(50, v)); await control.set_min_conf(v); await _reply(update, f"Минимална увереност: <b>{v}%</b>")

    def _is_pair(s: str) -> bool:
        s2 = s.replace(" ", "").upper()
        if "/" in s2: a, b = s2.split("/", 1)
        elif "_" in s2: a, b = s2.split("_", 1)
        else: return False
        return len(a) == 3 and len(b) == 3 and a.isalpha() and b.isalpha()

    async def cmd_pairs(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not _auth_ok(update, allowed_chat_ids): return
        if not context.args: return await _reply(update, "Използване: <code>/pairs list</code> | <code>/pairs add EUR/USD</code> | <code>/pairs remove EUR/USD</code>")
        sub = context.args[0].lower()
        if sub == "list":
            pairs = await control.get_pairs(); preview = ", ".join(pairs) if pairs else "—"
            return await _reply(update, f"Активни двойки ({len(pairs)}): {preview}")
        if sub == "add" and len(context.args) >= 2:
            pair = context.args[1].upper()
            if not _is_pair(pair): return await _reply(update, "Формат: <code>AAA/BBB</code>, напр. EUR/USD")
            await control.add_pair(pair); return await _reply(update, f"Добавена: <b>{pair}</b>")
        if sub == "remove" and len(context.args) >= 2:
            pair = context.args[1].upper()
            await control.remove_pair(pair); return await _reply(update, f"Премахната: <b>{pair}</b>")
        return await _reply(update, "Неподдържана подкоманда. Ползвай <code>/pairs list|add|remove</code>.")

    async def cmd_silent(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not _auth_ok(update, allowed_chat_ids): return
        arg = (context.args[0].lower() if context.args else "")
        if arg not in {"on", "off"}: return await _reply(update, "Използване: <code>/silent on</code> или <code>/silent off</code>")
        await control.set_silent(arg == "on"); await _reply(update, f"Silent: <b>{'ON' if arg=='on' else 'OFF'}</b>")

    async def cmd_smc(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not _auth_ok(update, allowed_chat_ids): return
        arg = (context.args[0].lower() if context.args else "")
        if arg not in {"on", "off"}: return await _reply(update, "Използване: <code>/smc on</code> или <code>/smc off</code>")
        await control.set_smc(arg == "on"); await _reply(update, f"SMC: <b>{'ON' if arg=='on' else 'OFF'}</b>")

    async def cmd_smcstrict(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not _auth_ok(update, allowed_chat_ids): return
        arg = (context.args[0].lower() if context.args else "")
        if arg not in {"on", "off"}: return await _reply(update, "Използване: <code>/smcstrict on</code> или <code>/smcstrict off</code>")
        await control.set_smc_strict(arg == "on"); await _reply(update, f"SMC Strict: <b>{'ON' if arg=='on' else 'OFF'}</b>")

    async def cmd_config(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not _auth_ok(update, allowed_chat_ids): return
        if not context.args or context.args[0].lower() == "show":
            st = await control.get_state()
            return await _reply(update, (
                "<b>SMC настройки</b>\n"
                f"swing_len={st.smc_swing_len}, internal_len={st.smc_internal_len}, ob_len={st.smc_ob_len}\n"
                f"mitigation={st.smc_mitigation}, eq_thresh={st.smc_eq_thresh_atr:.2f}, fvg_width={st.smc_fvg_width_atr_mult:.2f}\n"
                "Задаване: <code>/config set swing_len 60</code>\n"
                "Ключове: swing_len, internal_len, ob_len, mitigation, eq_thresh, fvg_width"
            ))
        if len(context.args) < 3 or context.args[0].lower() != "set":
            return await _reply(update, "Използване: <code>/config set &lt;key&gt; &lt;value&gt;</code>")
        key = context.args[1].lower(); val = " ".join(context.args[2:])
        key_map = {
            "swing_len": "swing_len",
            "internal_len": "internal_len",
            "ob_len": "ob_len",
            "mitigation": "mitigation",
            "eq_thresh": "eq_thresh",
            "fvg_width": "fvg_width",
        }
        if key not in key_map: return await _reply(update, "Невалиден ключ.")
        try:
            await control.set_smc_param(key_map[key], val)
        except Exception as e:
            return await _reply(update, f"Грешка при сет: {e}")
        return await _reply(update, f"Обновено: <b>{key} = {val}</b>")

    async def cmd_backtest(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not _auth_ok(update, allowed_chat_ids): return
        if not context.args:
            return await _reply(update, "Използване: <code>/backtest EUR/USD 1000</code> (bars<=2000)")
        pair = context.args[0].upper()
        bars = 1000
        if len(context.args) >= 2:
            try: bars = int(context.args[1])
            except Exception: pass
        bars = max(200, min(2000, bars))
        data_dir = update.application.bot_data.get("data_dir")
        if not data_dir:
            return await _reply(update, "Няма зададен data_dir в приложението.")
        st = await control.get_state()
        smc_params = dict(
            swing_len=st.smc_swing_len,
            internal_len=st.smc_internal_len,
            ob_len=st.smc_ob_len,
            ob_mitigation=st.smc_mitigation,
            eq_thresh_atr=st.smc_eq_thresh_atr,
            fvg_width_atr_mult=st.smc_fvg_width_atr_mult,
        )

        async def _run():
            from app.services.backtest import run_backtest
            txt = run_backtest(
                data_dir=data_dir, pair=pair, bars=bars,
                rr_base=st.risk_rr_base, min_conf=st.signal_min_confidence,
                smc_enabled=st.smc_enabled, smc_strict=st.smc_strict, smc_params=smc_params
            )
            await _reply(update, txt)

        asyncio.create_task(_run())

        await _reply(update, f"Започвам бектест за <b>{pair}</b> върху последните <b>{bars}</b> H1 бара…")

    # Регистрация
    app.add_handler(CommandHandler("help", cmd_help))
    app.add_handler(CommandHandler("status", cmd_status))
    app.add_handler(CommandHandler("signals", cmd_signals))
    app.add_handler(CommandHandler("news", cmd_news))
    app.add_handler(CommandHandler("risk", cmd_risk))
    app.add_handler(CommandHandler("confidence", cmd_confidence))
    app.add_handler(CommandHandler("pairs", cmd_pairs))
    app.add_handler(CommandHandler("silent", cmd_silent))
    app.add_handler(CommandHandler("smc", cmd_smc))
    app.add_handler(CommandHandler("smcstrict", cmd_smcstrict))
    app.add_handler(CommandHandler("config", cmd_config))
    app.add_handler(CommandHandler("backtest", cmd_backtest))
