from __future__ import annotations

from dataclasses import dataclass, field
from html import escape
from typing import Dict, List, Optional


MAX_TG_LEN = 4096
SUMMARY_LIMIT = 2000  # както пожела — под лимита на съобщението


@dataclass
class TrendImpact:
    direction: str  # "up" | "down" | "flat"
    pct: float      # влиянието като % (евристика от новината)


@dataclass
class NewsRender:
    stars: int                               # 1..4
    title: str
    summary_bg: str                          # вече преведено на BG (ще го превеждаме по-късно с DeepL)
    trend_by_ccy: Dict[str, TrendImpact]     # напр. {"EUR": TrendImpact("up", 0.6), "USD": TrendImpact("down", 0.3)}
    affected_ccy: List[str] = field(default_factory=list)  # напр. ["EUR","GBP","CHF","USD"]


STAR_FULL = "⭐️"
ARROW_UP = "▲"
ARROW_DN = "▼"
ARROW_FLAT = "■"


def _stars_line(n: int) -> str:
    n = max(1, min(4, n))
    return STAR_FULL * n + f" ({n}/4)"


def _dir_symbol(d: str) -> str:
    d = (d or "").lower()
    if d.startswith("up") or d == "+":
        return ARROW_UP
    if d.startswith("down") or d == "-":
        return ARROW_DN
    return ARROW_FLAT


def _fmt_pct(x: float) -> str:
    try:
        return f"{float(x):.1f}%"
    except Exception:
        return "0.0%"


def _fmt_trend_block(trend_by_ccy: Dict[str, TrendImpact]) -> str:
    if not trend_by_ccy:
        return "Тренд: н/д"
    parts = []
    # Показваме най-много 4 валути в реда "EUR ▲ (+0.6%) | USD ▼ (-0.3%)"
    for ccy, ti in list(trend_by_ccy.items())[:4]:
        arrow = _dir_symbol(ti.direction)
        sign = "+" if (ti.direction.lower().startswith("up") or ti.pct >= 0) else ""
        parts.append(f"{escape(ccy)} {arrow} ({sign}{_fmt_pct(ti.pct)})")
    return "Тренд: " + " | ".join(parts)


def _fmt_influence_line(affected: List[str], trend_by_ccy: Dict[str, TrendImpact]) -> str:
    if not affected:
        # вземи до 4 ключа от trend_by_ccy като дефолт
        affected = list(trend_by_ccy.keys())[:4]
    pieces = []
    for ccy in affected[:4]:
        ti = trend_by_ccy.get(ccy)
        if ti:
            tag = "силно" if abs(ti.pct) >= 0.8 else ("умерено" if abs(ti.pct) >= 0.4 else "слабо")
            arrow = _dir_symbol(ti.direction)
            pieces.append(f"{escape(ccy)} ({tag} {arrow})")
        else:
            pieces.append(f"{escape(ccy)}")
    return "Влияние: " + ", ".join(pieces)


def _safe_trim(text: str, limit: int = SUMMARY_LIMIT) -> str:
    text = (text or "").strip()
    if len(text) <= limit:
        return text
    # режем на граница на изречение/дума
    cut = text[: limit - 1]
    for sep in (". ", "! ", "? ", "\n"):
        idx = cut.rfind(sep)
        if idx >= 0 and idx > limit * 0.6:
            cut = cut[: idx + 1]
            break
    return cut + "…"


def format_news_message(n: NewsRender) -> str:
    """
    Финален HTML за Telegram:
    ⭐️⭐️⭐️ (3/4)
    Заглавие: ...
    Обобщение: ...
    Тренд: EUR ▲ (+0.6%) | USD ▼ (-0.3%)
    Влияние: EUR (силно ▲), GBP (умерено ▲), CHF (слабо ▲), USD (умерено ▼)
    """
    stars = _stars_line(n.stars)
    title = f"Заглавие: {escape(n.title)}"
    summary = f"Обобщение: {escape(_safe_trim(n.summary_bg, SUMMARY_LIMIT))}"
    trend = _fmt_trend_block(n.trend_by_ccy)
    influence = _fmt_influence_line(n.affected_ccy, n.trend_by_ccy)

    body = "\n".join([stars, title, summary, trend, influence])

    # гаранция за лимита на Telegram
    if len(body) > MAX_TG_LEN:
        body = body[: MAX_TG_LEN - 1] + "…"
    return body


# ---- Примерен формат на сигнал (ENTRY/SL/TP1,2) — ще го използваме по-късно ----

@dataclass
class SignalRender:
    pair: str                 # "EUR/USD"
    timeframe: str            # "H1"
    direction: str            # "BUY" | "SELL"
    entry: float
    sl: float
    tp_levels: List[float]    # [tp1, tp2]
    confidence: int           # 0..100
    context: Optional[str] = None  # кратък коментар/основание


def format_signal_message(s: SignalRender) -> str:
    """
    Приятелски HTML формат за сигнал.
    """
    arrow = "🟢" if s.direction.upper() == "BUY" else "🔴"
    tps = ", ".join(f"{x:.5f}" for x in s.tp_levels[:2]) if s.tp_levels else "—"
    lines = [
        f"{arrow} <b>{escape(s.pair)}</b> <i>{escape(s.timeframe)}</i> — <b>{escape(s.direction.upper())}</b>",
        f"ENTRY: <b>{s.entry:.5f}</b>",
        f"SL: <b>{s.sl:.5f}</b>",
        f"TP1/TP2: <b>{tps}</b>",
        f"Увереност: <b>{s.confidence}%</b>",
    ]
    if s.context:
        lines.append("Коментар: " + escape(s.context.strip()))
    text = "\n".join(lines)
    return text if len(text) <= MAX_TG_LEN else text[: MAX_TG_LEN - 1] + "…"
