from __future__ import annotations

from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import Application, ApplicationBuilder, CommandHandler, ContextTypes

from app.utils.logger import get_logger
from app.utils.ratelimit import RateLimiter


class Notifier:
    """
    Broadcast към един или няколко chat_id, с chunk-ване под лимита на Telegram.
    """
    def __init__(self, app: Application, chat_ids, rate_limit_per_min: int = 55):
        self.app = app
        self.chat_ids = list(chat_ids)
        self._limiter = RateLimiter(rate_limit_per_min, 60.0)
        self.logger = get_logger("telegram.notifier")

    @staticmethod
    def _split_chunks(text: str, limit: int = 3900):
        if len(text) <= limit:
            return [text]
        chunks, buf, total = [], [], 0
        for line in text.splitlines(keepends=True):
            if total + len(line) > limit and buf:
                chunks.append("".join(buf))
                buf, total = [line], len(line)
            else:
                buf.append(line)
                total += len(line)
        if buf:
            chunks.append("".join(buf))
        return chunks

    async def send_text(self, text: str, parse_mode: str = ParseMode.HTML, disable_preview: bool = True):
        if not text:
            return
        for chunk in self._split_chunks(text):
            for chat_id in self.chat_ids:
                async with self._limiter:
                    try:
                        await self.app.bot.send_message(
                            chat_id=chat_id,
                            text=chunk,
                            parse_mode=parse_mode,
                            disable_web_page_preview=disable_preview,
                        )
                    except Exception as e:
                        self.logger.error("send_text:error", extra={"chat_id": chat_id, "err": str(e)})


async def _cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("✅ Ботът е онлайн. Използвай /help за команди.")


async def _cmd_ping(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("pong")


async def _cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    summary = context.application.bot_data.get("app_summary", "н/д")
    await update.message.reply_text(f"Статус: {summary}")


def build_application(token: str, app_summary: str = "") -> Application:
    app = ApplicationBuilder().token(token).build()
    app.add_handler(CommandHandler("start", _cmd_start))
    app.add_handler(CommandHandler("ping", _cmd_ping))
    app.add_handler(CommandHandler("status", _cmd_status))
    app.bot_data["app_summary"] = app_summary
    return app


async def start_polling(app: Application):
    await app.initialize()
    await app.start()
    await app.updater.start_polling()


async def stop_polling(app: Application):
    try:
        await app.updater.stop()
    except Exception:
        pass
    try:
        await app.stop()
    except Exception:
        pass
    try:
        await app.shutdown()
    except Exception:
        pass
