from __future__ import annotations

import asyncio
import time
from typing import Iterable, List, Optional

import httpx


TG_API_BASE = "https://api.telegram.org"


def _chunk_text(s: str, hard_limit: int = 4000) -> List[str]:
    """
    Разбива текста на части <= hard_limit.
    Опитва по параграфи/редове. Ако няма как – твърдо реже.
    """
    if not s:
        return [""]

    if len(s) <= hard_limit:
        return [s]

    parts: List[str] = []
    buf: List[str] = []
    cur_len = 0

    # Първо по параграфи
    for para in s.split("\n\n"):
        if cur_len + len(para) + (2 if buf else 0) <= hard_limit:
            buf.append(para)
            cur_len += len(para) + (2 if buf[:-1] else 0)
        else:
            # ако параграфът е прекалено голям – режи по редове
            if buf:
                parts.append("\n\n".join(buf))
                buf, cur_len = [], 0

            if len(para) <= hard_limit:
                parts.append(para)
            else:
                # твърдо рязане по hard_limit
                i = 0
                while i < len(para):
                    parts.append(para[i:i + hard_limit])
                    i += hard_limit

    if buf:
        parts.append("\n\n".join(buf))

    return parts


async def send_text(
    token: str,
    chat_id: str | int,
    text: str,
    parse_mode: Optional[str] = "HTML",
    disable_web_page_preview: bool = True,
    disable_notification: bool = False,
    client: Optional[httpx.AsyncClient] = None,
) -> None:
    """
    Надеждно изпращане на текст към Telegram (с chunking и леки backoff-и).
    Вдига Exception, ако Telegram върне грешка – за да се види в логовете.
    """
    close_client = False
    if client is None:
        client = httpx.AsyncClient(timeout=20.0)
        close_client = True

    try:
        url = f"{TG_API_BASE}/bot{token}/sendMessage"
        chunks = _chunk_text(text, hard_limit=4000)
        for idx, part in enumerate(chunks, 1):
            payload = {
                "chat_id": str(chat_id),
                "text": part,
                "disable_web_page_preview": disable_web_page_preview,
                "disable_notification": disable_notification,
            }
            if parse_mode:
                payload["parse_mode"] = parse_mode

            r = await client.post(url, data=payload)
            # Telegram винаги връща 200 – проверяваме 'ok'
            data = r.json()
            if not data.get("ok", False):
                raise RuntimeError(f"Telegram error: {data!r}")

            # леко забавяне за да избегнем flood control
            if idx < len(chunks):
                await asyncio.sleep(0.4)
    finally:
        if close_client:
            await client.aclose()


def send_text_sync(
    token: str,
    chat_id: str | int,
    text: str,
    parse_mode: Optional[str] = "HTML",
    disable_web_page_preview: bool = True,
    disable_notification: bool = False,
) -> None:
    """
    Синхронна обвивка (за извикване от обикновен код / service).
    """
    asyncio.run(
        send_text(
            token=token,
            chat_id=chat_id,
            text=text,
            parse_mode=parse_mode,
            disable_web_page_preview=disable_web_page_preview,
            disable_notification=disable_notification,
        )
    )
