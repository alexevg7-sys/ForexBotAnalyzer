from __future__ import annotations

import asyncio
from typing import List, Optional

import httpx


class DeepLClient:
    """
    Лек async клиент за DeepL (работи и с Free ключове `:fx`).
    - Автоматично избира правилния домейн: api-free.deepl.com за *:fx*; иначе api.deepl.com
    - translate(text, target="BG") -> str
    - translate_many(list[str], target="BG") -> list[str]
    """
    def __init__(self, api_key: str, rate_limit_per_min: int = 50):
        self.api_key = api_key.strip()
        self.base = "https://api-free.deepl.com" if self.api_key.endswith(":fx") else "https://api.deepl.com"
        self._client = httpx.AsyncClient(base_url=self.base, timeout=20.0)
        # скромен семафор — да не минаваме 50/мин
        self._sem = asyncio.Semaphore(max(1, rate_limit_per_min))

    async def _post(self, path: str, data: dict) -> Optional[dict]:
        data = dict(data or {})
        data["auth_key"] = self.api_key
        async with self._sem:
            r = await self._client.post(path, data=data)
        # ако има грешка, върни None — caller ще ползва оригиналния текст
        if r.status_code != 200:
            return None
        try:
            return r.json()
        except Exception:
            return None

    async def translate(self, text: str, target: str = "BG") -> str:
        if not text:
            return text
        resp = await self._post("/v2/translate", {"text": text, "target_lang": target})
        try:
            return (resp or {}).get("translations", [{}])[0].get("text") or text
        except Exception:
            return text

    async def translate_many(self, texts: List[str], target: str = "BG") -> List[str]:
        if not texts:
            return []
        # DeepL приема многократни "text" полета
        data = [("auth_key", self.api_key), ("target_lang", target)]
        for t in texts:
            data.append(("text", t or ""))
        async with self._sem:
            r = await self._client.post("/v2/translate", data=data)
        if r.status_code != 200:
            return texts
        try:
            js = r.json()
            outs = [tr.get("text","") for tr in js.get("translations", [])]
            # защита: при несъвпадение върни оригиналите
            return outs if len(outs) == len(texts) else texts
        except Exception:
            return texts

    async def aclose(self):
        try:
            await self._client.aclose()
        except Exception:
            pass
