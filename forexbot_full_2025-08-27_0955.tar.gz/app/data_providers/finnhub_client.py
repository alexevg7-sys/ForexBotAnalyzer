from __future__ import annotations

import asyncio
from typing import List, Dict, Any, Optional

import httpx

from app.utils.logger import get_logger


class FinnhubClient:
    """
    Минимален async клиент към Finnhub /news за категория 'forex'.
    Върща списък от обекти с ключове: headline, summary, datetime.
    """
    def __init__(self, api_key: str, rate_limit_per_min: int = 55):
        self.api_key = api_key
        self.base_url = "https://finnhub.io/api/v1"
        self._client = httpx.AsyncClient(base_url=self.base_url, timeout=20.0)
        self._last_news_id: int = 0
        self._sem = asyncio.Semaphore(max(1, rate_limit_per_min // 2))
        self.logger = get_logger("finnhub")

    async def _get(self, path: str, params: Dict[str, Any]) -> Optional[httpx.Response]:
        params = dict(params or {})
        params["token"] = self.api_key
        async with self._sem:
            try:
                r = await self._client.get(path, params=params)
                return r
            except Exception as e:
                self.logger.exception("finnhub:get:error", extra={"path": path, "err": str(e)})
                return None

    async def fetch_forex_news(self, limit: int = 50) -> List[Dict[str, Any]]:
        """
        Взима последните FOREX новини. Използва minId за инкрементално четене.
        Fallback: ако категория 'forex' върне празно, пробва 'general'.
        """
        items: List[Dict[str, Any]] = []

        # 1) опит с category=forex
        r = await self._get("/news", {"category": "forex", "minId": self._last_news_id})
        if r and r.status_code == 200:
            try:
                data = r.json()
                if isinstance(data, list):
                    items = data
            except Exception:
                self.logger.exception("finnhub:parse:forex")

        # 2) fallback към general, ако нужно
        if not items:
            r2 = await self._get("/news", {"category": "general", "minId": self._last_news_id})
            if r2 and r2.status_code == 200:
                try:
                    data2 = r2.json()
                    if isinstance(data2, list):
                        # филтрирай само релевантни към FX по ключови думи
                        fx_keys = ("usd","eur","jpy","gbp","chf","cad","aud","nzd","forex","currency","ecb","fed","boj","boe","boc","rbnz","rba","snb")
                        def is_fx(x: Dict[str, Any]) -> bool:
                            t = (x.get("headline") or "" + " " + x.get("summary") or "").lower()
                            return any(k in t for k in fx_keys)
                        items = [x for x in data2 if is_fx(x)]
                except Exception:
                    self.logger.exception("finnhub:parse:general")

        # нормализирай полетата и поддържай last id
        out: List[Dict[str, Any]] = []
        for it in items[:limit]:
            dt = int(it.get("datetime") or it.get("time") or 0)
            head = it.get("headline") or it.get("title") or ""
            summ = it.get("summary") or it.get("description") or ""
            nid = int(it.get("id") or 0)
            if nid > self._last_news_id:
                self._last_news_id = nid
            if head and dt:
                out.append({"headline": head, "summary": summ, "datetime": dt, "id": nid})

        # сортирай по време възходящо (за да се публикуват по ред)
        out.sort(key=lambda x: x["datetime"])
        return out

    async def aclose(self):
        try:
            await self._client.aclose()
        except Exception:
            pass
