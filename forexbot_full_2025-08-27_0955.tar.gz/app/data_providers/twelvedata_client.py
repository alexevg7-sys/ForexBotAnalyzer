from __future__ import annotations

import asyncio
import re
from dataclasses import dataclass
from typing import Optional, Dict, Any

import httpx
import pandas as pd


# ---- съвместимост (ползва се в MarketCache за type hints) ----
@dataclass
class Candle:
    datetime: str
    open: float
    high: float
    low: float
    close: float
    volume: float


def normalize_interval(iv: str) -> str:
    """
    Нормализира разнообразни записи:
      15m -> 15min
      60m/60min -> 1h
      240m/240min -> 4h
      (всички Xmin, ако X%60==0 -> (X/60)h)
    """
    iv = (iv or "").lower().strip()
    mapping = {
        "1m": "1min", "5m": "5min", "15m": "15min", "30m": "30min", "45m": "45min",
        "60m": "1h", "120m": "2h", "180m": "3h", "240m": "4h",
        "60min": "1h", "120min": "2h", "180min": "3h", "240min": "4h",
    }
    if iv in mapping:
        return mapping[iv]
    m = re.fullmatch(r"(\d+)\s*min", iv)
    if m:
        mins = int(m.group(1))
        if mins % 60 == 0:
            return f"{mins//60}h"
        return f"{mins}min"
    return iv  # вече може да е 1h/4h/1day и т.н.


class TwelveDataClient:
    """Минимален async клиент към TwelveData /time_series."""
    def __init__(self, api_key: str, rate_limit_per_min: int = 55):
        self.api_key = api_key
        self.base_url = "https://api.twelvedata.com"
        self._client = httpx.AsyncClient(base_url=self.base_url, timeout=20.0)
        self._sem = asyncio.Semaphore(max(1, rate_limit_per_min))

    async def _get(self, path: str, params: Dict[str, Any]) -> Optional[dict]:
        q = dict(params or {})
        q["apikey"] = self.api_key
        async with self._sem:
            r = await self._client.get(path, params=q)
        r.raise_for_status()
        data = r.json()
        if isinstance(data, dict) and data.get("status") == "error":
            raise RuntimeError(data.get("message", "TwelveData error"))
        return data

    async def fetch_ohlc(self, pair: str, interval: str, outputsize: int = 120) -> Optional[pd.DataFrame]:
        """
        Връща DataFrame с колони: datetime, open, high, low, close, volume (volume може да липсва ⇒ попълваме 0).
        """
        sym = pair.replace("_", "/").upper()
        iv = normalize_interval(interval)
        data = await self._get(
            "/time_series",
            {"symbol": sym, "interval": iv, "outputsize": int(outputsize), "order": "desc"}
        )
        if not isinstance(data, dict) or "values" not in data or not data["values"]:
            return None

        df = pd.DataFrame(data["values"])
        # Преименуване/типове
        need_cols = ["datetime", "open", "high", "low", "close"]
        for c in need_cols + (["volume"] if "volume" in df.columns else []):
            if c in df.columns:
                df[c] = pd.to_numeric(df[c], errors="coerce") if c != "datetime" else df[c]

        if "datetime" not in df.columns:
            return None
        df["datetime"] = pd.to_datetime(df["datetime"])
        df = df.sort_values("datetime").reset_index(drop=True)

        # Volume може да липсва за FX — създаваме нули
        if "volume" not in df.columns:
            df["volume"] = 0.0

        return df[["datetime", "open", "high", "low", "close", "volume"]]

    async def aclose(self):
        try:
            await self._client.aclose()
        except Exception:
            pass
