from __future__ import annotations

import asyncio
import json
from typing import Iterable, List, Optional

import httpx


TELEGRAM_API = "https://api.telegram.org/bot{token}/sendMessage"
# твърд лимит на Телеграм за текст
TG_LIMIT = 4096


def _split_soft(text: str, limit: int = TG_LIMIT) -> List[str]:
    """
    Режем текста на части с дължина <= limit.
    Опитваме първо по двойни нови редове (параграфи), после по единични,
    накрая – твърдо рязане, за да гарантираме изпращане.
    """
    if not text:
        return [""]

    if len(text) <= limit:
        return [text]

    parts: List[str] = []

    remaining = text
    while remaining:
        if len(remaining) <= limit:
            parts.append(remaining)
            break

        # пробваме най-дълъг параграф, който се побира
        cut = remaining.rfind("\n\n", 0, limit)
        if cut == -1:
            cut = remaining.rfind("\n", 0, limit)
        if cut == -1:
            # твърд cut – да не блокираме
            cut = limit

        parts.append(remaining[:cut].rstrip())
        remaining = remaining[cut:].lstrip()

    return [p for p in parts if p]


async def _post_text(
    token: str,
    chat_id: str | int,
    text: str,
    parse_mode: Optional[str] = "HTML",
    disable_web_page_preview: bool = True,
    disable_notification: bool = False,
) -> httpx.Response:
    url = TELEGRAM_API.format(token=token)
    payload = {
        "chat_id": chat_id,
        "text": text,
        "disable_web_page_preview": disable_web_page_preview,
        "disable_notification": disable_notification,
    }
    if parse_mode:
        payload["parse_mode"] = parse_mode

    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.post(url, json=payload)
        # ще повдигнем HTTP грешките, за да ги обработим по-долу
        try:
            r.raise_for_status()
        except httpx.HTTPStatusError as e:
            # При 400 ще ни трябва тялото за диагностика
            e.response_text = ""
            try:
                e.response_text = r.text
            except Exception:
                pass
            raise
        return r


async def send_text_async(
    token: str,
    chat_id: str | int,
    text: str,
) -> None:
    """
    Надеждно изпращане: chunking + retry + HTML fallback без да спираме потока.
    """
    chunks = _split_soft(text, TG_LIMIT)

    for part in chunks:
        parse_mode: Optional[str] = "HTML"
        attempt = 0
        while True:
            attempt += 1
            try:
                await _post_text(
                    token=token,
                    chat_id=chat_id,
                    text=part,
                    parse_mode=parse_mode,
                    disable_web_page_preview=True,
                    disable_notification=False,
                )
                break  # успешно
            except httpx.HTTPStatusError as e:
                status = e.response.status_code
                body = getattr(e, "response_text", "") or ""
                lower = body.lower()

                # 429 Too Many Requests -> уважаваме retry_after
                if status == 429:
                    retry_after = 1
                    try:
                        data = json.loads(body)
                        retry_after = int(
                            data.get("parameters", {}).get("retry_after", 1)
                        )
                    except Exception:
                        pass
                    await asyncio.sleep(retry_after + 1)
                    continue

                # 400 Bad Request -> често "can't parse entities"
                if status == 400 and ("can't parse entities" in lower or "parse entities" in lower):
                    # изпращаме без HTML
                    if parse_mode is not None:
                        parse_mode = None
                        # малка пауза и опит отново
                        await asyncio.sleep(0.1)
                        continue

                # друго -> не въртим безкрайно
                raise


def send_text(token: str, chat_id: str | int, text: str) -> None:
    """Синхронна обвивка за удобство при извикване от други модули/скриптове."""
    asyncio.run(send_text_async(token, chat_id, text))


__all__ = ["send_text", "send_text_async"]
