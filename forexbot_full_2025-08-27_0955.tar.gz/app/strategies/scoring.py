from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ScoreContext:
    trend_align: int       # -1,0,1 (H4 тренд спрямо посока на сигнала)
    macd_strength: float   # 0..1 (|hist| нормализирана)
    rsi_confirm: int       # -1,0,1 (M15 над/под 50 в посока)
    candle_power: float    # 0..1 (сила на H1 свещ)
    structure_break: int   # 0..1 (има ли break на последния swing)
    news_bias: int         # -2..+2 (news guard ефект)
    extra_bonus: int = 0   # бъдещи Pine интеграции


def to_confidence(ctx: ScoreContext) -> int:
    """
    Превръща факторите в 0..100.
    Базова 50, след което добавяме/изваждаме тежести.
    """
    score = 50
    score += 15 * ctx.trend_align          # +-15
    score += int(20 * min(1.0, max(0.0, ctx.macd_strength)))  # +0..20
    score += 10 * ctx.rsi_confirm          # +-10
    score += int(10 * ctx.candle_power)    # +0..10
    score += 10 * ctx.structure_break      # +0..10
    score += 10 * ctx.news_bias            # -20..+20
    score += ctx.extra_bonus               # по избор
    return max(0, min(100, score))
