from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple, Literal, Dict

import pandas as pd


Dir = Literal["bullish", "bearish"]
MaybeDir = Optional[Dir]


@dataclass
class OBZone:
    kind: Dir                # bullish|bearish
    low: float               # граници на зоната (тяло на OB свещта)
    high: float
    mid: float               # средна цена
    near: bool               # текущата цена близо ли е до зоната (<= 0.25*ATR)
    idx: pd.Timestamp        # индекс/време на OB свещта


@dataclass
class FVG:
    kind: Dir
    lower: float             # граници на gap-а
    upper: float
    in_gap: bool             # текущата цена вътре ли е в gap-а
    filled: bool             # gap-ът вече е „затворен“
    idx: pd.Timestamp        # индекс на свещта, където е маркиран gap-ът


@dataclass
class Sweep:
    kind: Literal["buy", "sell"]
    level: float             # swept ниво
    idx: pd.Timestamp


@dataclass
class SMCResult:
    bos: MaybeDir            # Break of Structure на H1
    ob: Optional[OBZone]
    fvg: Optional[FVG]
    sweep: Optional[Sweep]
    bonus: int               # + точки за увереност (0..+20)
    conflict: bool           # силно противоречие спрямо посоката


def _atr_like(df: pd.DataFrame, period: int = 14) -> float:
    pc = df["close"].shift(1)
    tr = pd.concat([
        (df["high"] - df["low"]).abs(),
        (df["high"] - pc).abs(),
        (df["low"] - pc).abs(),
    ], axis=1).max(axis=1)
    return float(tr.rolling(period, min_periods=1).mean().iloc[-1])


def detect_bos(df_h1: pd.DataFrame, lookback: int = 20) -> MaybeDir:
    if len(df_h1) < lookback + 2:
        return None
    last_close = float(df_h1["close"].iloc[-1])
    window = df_h1.iloc[-(lookback+1):-1]
    if last_close > float(window["high"].max()):
        return "bullish"
    if last_close < float(window["low"].min()):
        return "bearish"
    return None


def detect_order_block(df_h1: pd.DataFrame, bos: MaybeDir) -> Optional[OBZone]:
    """
    Bullish OB: последната меча свещ преди импулс нагоре (BOS up).
    Bearish OB: последната бича свещ преди импулс надолу (BOS down).
    Взимаме тялото на тази свещ като зона.
    """
    if bos is None or len(df_h1) < 30:
        return None
    last_idx = df_h1.index[-1]
    atr14 = _atr_like(df_h1, 14)
    # търси назад до 25 свещи
    rng = range(len(df_h1) - 2, max(1, len(df_h1) - 25), -1)
    for i in rng:
        o = float(df_h1["open"].iloc[i])
        c = float(df_h1["close"].iloc[i])
        if bos == "bullish" and c < o:  # меча свещ
            low, high = (min(o, c), max(o, c))
            mid = (low + high) / 2.0
            near = abs(float(df_h1["close"].iloc[-1]) - mid) <= 0.25 * atr14
            return OBZone(kind="bullish", low=low, high=high, mid=mid, near=near, idx=df_h1.index[i])
        if bos == "bearish" and c > o:  # бича свещ
            low, high = (min(o, c), max(o, c))
            mid = (low + high) / 2.0
            near = abs(float(df_h1["close"].iloc[-1]) - mid) <= 0.25 * atr14
            return OBZone(kind="bearish", low=low, high=high, mid=mid, near=near, idx=df_h1.index[i])
    return None


def detect_fvg(df_h1: pd.DataFrame, scan: int = 10) -> Optional[FVG]:
    """
    3-свещен FVG:
      - bullish: low[i] > high[i-2]
      - bearish: high[i] < low[i-2]
    Сканираме последните `scan` свещи и взимаме най-близкия.
    """
    if len(df_h1) < 5:
        return None
    for j in range(len(df_h1) - 1, max(2, len(df_h1) - scan) - 1, -1):
        i = j
        i2 = j - 2
        low_i = float(df_h1["low"].iloc[i])
        high_i2 = float(df_h1["high"].iloc[i2])
        high_i = float(df_h1["high"].iloc[i])
        low_i2 = float(df_h1["low"].iloc[i2])
        close_last = float(df_h1["close"].iloc[-1])

        if low_i > high_i2:
            lower, upper = high_i2, low_i
            in_gap = lower <= close_last <= upper
            filled = float(df_h1["low"].iloc[i - 1]) <= upper and float(df_h1["high"].iloc[i - 1]) >= lower
            return FVG(kind="bullish", lower=lower, upper=upper, in_gap=in_gap, filled=filled, idx=df_h1.index[i])
        if high_i < low_i2:
            lower, upper = high_i, low_i2
            in_gap = lower <= close_last <= upper
            filled = float(df_h1["low"].iloc[i - 1]) <= upper and float(df_h1["high"].iloc[i - 1]) >= lower
            return FVG(kind="bearish", lower=lower, upper=upper, in_gap=in_gap, filled=filled, idx=df_h1.index[i])
    return None


def detect_sweep(df_h1: pd.DataFrame, lookback: int = 20) -> Optional[Sweep]:
    """
    Liquidity sweep: последната свещ „прободе“ най-близкия swing, но затвори обратно.
    """
    if len(df_h1) < lookback + 3:
        return None
    last = df_h1.iloc[-1]
    window = df_h1.iloc[-(lookback+1):-1]
    prev_high = float(window["high"].max())
    prev_low = float(window["low"].min())
    if float(last["high"]) > prev_high and float(last["close"]) < prev_high:
        return Sweep(kind="sell", level=prev_high, idx=df_h1.index[-1])
    if float(last["low"]) < prev_low and float(last["close"]) > prev_low:
        return Sweep(kind="buy", level=prev_low, idx=df_h1.index[-1])
    return None


def analyze_smc(df_h1: pd.DataFrame) -> SMCResult:
    """
    Основен анализ върху H1 (най-релевантен за входа ни).
    """
    bos = detect_bos(df_h1, lookback=20)
    ob = detect_order_block(df_h1, bos)
    fvg = detect_fvg(df_h1, scan=12)
    sweep = detect_sweep(df_h1, lookback=20)

    # бонуси и конфликти се решават спрямо посоката по-късно в енджина
    return SMCResult(bos=bos, ob=ob, fvg=fvg, sweep=sweep, bonus=0, conflict=False)


def smc_bonus_and_conflict(smc: SMCResult, signal_dir: Literal["BUY", "SELL"]) -> Tuple[int, bool, str]:
    """
    Връща (bonus_points [0..20], conflict_flag, human_summary)
    """
    if smc is None:
        return 0, False, "SMC: н/д"

    parts = []
    bonus = 0
    conflict = False

    # BOS
    if smc.bos:
        parts.append(f"BOS: {'↑' if smc.bos=='bullish' else '↓'}")
        if (smc.bos == "bullish" and signal_dir == "BUY") or (smc.bos == "bearish" and signal_dir == "SELL"):
            bonus += 8
        else:
            conflict = True

    # OB
    if smc.ob:
        parts.append(f"OB({ 'B' if smc.ob.kind=='bullish' else 'S' }) @~{smc.ob.mid:.5f}{' (near)' if smc.ob.near else ''}")
        if smc.ob.near:
            if (smc.ob.kind == "bullish" and signal_dir == "BUY") or (smc.ob.kind == "bearish" and signal_dir == "SELL"):
                bonus += 5
            else:
                conflict = True

    # FVG
    if smc.fvg:
        parts.append(f"FVG({ 'B' if smc.fvg.kind=='bullish' else 'S' }) {smc.fvg.lower:.5f}-{smc.fvg.upper:.5f}{' (in)' if smc.fvg.in_gap else ''}{' (filled)' if smc.fvg.filled else ''}")
        if (smc.fvg.kind == "bullish" and signal_dir == "BUY") or (smc.fvg.kind == "bearish" and signal_dir == "SELL"):
            bonus += 4

    # Sweep
    if smc.sweep:
        parts.append(f"Sweep({ 'BUY' if smc.sweep.kind=='buy' else 'SELL' })")
        if (smc.sweep.kind == "buy" and signal_dir == "BUY") or (smc.sweep.kind == "sell" and signal_dir == "SELL"):
            bonus += 3
        else:
            # sweep срещу посоката — слаб конфликт
            conflict = conflict or True

    bonus = max(0, min(20, bonus))
    return bonus, conflict, "SMC: " + ", ".join(parts) if parts else "SMC: —"
