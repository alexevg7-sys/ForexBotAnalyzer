from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, Optional, Tuple, List, Dict

import numpy as np
import pandas as pd


Dir = Literal["bullish", "bearish"]


# ---------- помощни ----------

def _atr(df: pd.DataFrame, period: int = 200) -> pd.Series:
    pc = df["close"].shift(1)
    tr = pd.concat([
        (df["high"] - df["low"]).abs(),
        (df["high"] - pc).abs(),
        (df["low"] - pc).abs(),
    ], axis=1).max(axis=1)
    return tr.rolling(period, min_periods=1).mean()


def _hl2(s_high: pd.Series, s_low: pd.Series) -> pd.Series:
    return (s_high + s_low) / 2.0


def _pivot_high(s: pd.Series, left: int, right: int) -> pd.Series:
    """True на i, ако High[i] е макс в прозорец [i-left, i+right]."""
    vals = s.values
    n = len(vals)
    out = np.zeros(n, dtype=bool)
    for i in range(left, n - right):
        seg = vals[i - left:i + right + 1]
        if vals[i] == np.max(seg):
            out[i] = True
    return pd.Series(out, index=s.index)


def _pivot_low(s: pd.Series, left: int, right: int) -> pd.Series:
    vals = s.values
    n = len(vals)
    out = np.zeros(n, dtype=bool)
    for i in range(left, n - right):
        seg = vals[i - left:i + right + 1]
        if vals[i] == np.min(seg):
            out[i] = True
    return pd.Series(out, index=s.index)


def _last_true_idx(s: pd.Series) -> Optional[pd.Timestamp]:
    w = s[s == True]
    if w.empty:
        return None
    return w.index[-1]


# ---------- данни за детекции ----------

@dataclass
class Event:
    tag: Literal["BOS", "CHoCH"]
    dir: Dir
    level: float
    when: pd.Timestamp


@dataclass
class OBZone:
    dir: Dir
    top: float
    bottom: float
    avg: float
    left_ts: pd.Timestamp
    mitigated: bool
    near: bool  # близо ли е текущата цена до mid (<= 0.25*ATR)


@dataclass
class FVG:
    dir: Dir
    lower: float
    upper: float
    avg: float
    in_gap: bool
    reached: bool
    when: pd.Timestamp


@dataclass
class Sweep:
    kind: Literal["buy", "sell"]
    level: float
    when: pd.Timestamp


@dataclass
class EQ:
    eqh: bool
    eql: bool
    level_h: Optional[float]
    level_l: Optional[float]


@dataclass
class SMCReport:
    swing: Optional[Event]
    internal: Optional[Event]
    ob_bull: List[OBZone]
    ob_bear: List[OBZone]
    fvg: Optional[FVG]
    sweep: Optional[Sweep]
    eq: EQ


# ---------- детекции (приближени към LuxAlgo логиките) ----------

def detect_structure(df: pd.DataFrame, left: int, right: int) -> Tuple[Optional[Event], Optional[float], Optional[float]]:
    """
    Открива последен BOS/CHoCH спрямо пресичане на последните swing нива.
    Връща (event, last_swing_high, last_swing_low).
    """
    hi = _pivot_high(df["high"], left, right)
    lo = _pivot_low(df["low"], left, right)
    last_hi_ts = _last_true_idx(hi)
    last_lo_ts = _last_true_idx(lo)
    if last_hi_ts is None or last_lo_ts is None:
        return None, None, None

    last_hi = float(df.loc[last_hi_ts, "high"])
    last_lo = float(df.loc[last_lo_ts, "low"])
    last = df.iloc[-1]

    # „последно оформеният“ pivot определя bias-а
    last_pivot = last_hi_ts if last_hi_ts > last_lo_ts else last_lo_ts
    prev_bias = "bearish" if last_pivot == last_hi_ts else "bullish"

    # пресичане на нивата
    if last["close"] > last_hi:
        tag = "CHoCH" if prev_bias == "bearish" else "BOS"
        return Event(tag=tag, dir="bullish", level=last_hi, when=df.index[-1]), last_hi, last_lo
    if last["close"] < last_lo:
        tag = "CHoCH" if prev_bias == "bullish" else "BOS"
        return Event(tag=tag, dir="bearish", level=last_lo, when=df.index[-1]), last_hi, last_lo

    return None, last_hi, last_lo


def detect_eq(df: pd.DataFrame, atr_val: float, left: int = 3, right: int = 3, thresh: float = 0.1) -> EQ:
    """EQH/EQL: две близки върха/дъна в рамките на thresh*ATR."""
    hi = _pivot_high(df["high"], left, right)
    lo = _pivot_low(df["low"], left, right)
    idx_h = hi[hi].index[-2:] if hi.sum() >= 2 else []
    idx_l = lo[lo].index[-2:] if lo.sum() >= 2 else []

    eqh = eql = False
    lvl_h = lvl_l = None

    if len(idx_h) == 2:
        a, b = float(df.loc[idx_h[0], "high"]), float(df.loc[idx_h[1], "high"])
        if abs(a - b) <= atr_val * thresh:
            eqh, lvl_h = True, (a + b) / 2.0

    if len(idx_l) == 2:
        a, b = float(df.loc[idx_l[0], "low"]), float(df.loc[idx_l[1], "low"])
        if abs(a - b) <= atr_val * thresh:
            eql, lvl_l = True, (a + b) / 2.0

    return EQ(eqh=eqh, eql=eql, level_h=lvl_h, level_l=lvl_l)


def detect_ob(df: pd.DataFrame, length: int = 5, mitigation: Literal["wick", "close"] = "wick") -> Tuple[List[OBZone], List[OBZone]]:
    """
    Приближение към Lux 'Order Block Detector':
    - os режим: 1 ако low[length] < lowest(length), 0 ако high[length] > highest(length)
    - bull OB при os==1 и volume pivot high (fallback: price pivot high при липса на volume)
    - bear OB при os==0 и volume pivot high
    Митигиране: за bull ако текущата цена (wick/close) < bottom; за bear ако (wick/close) > top.
    """
    n = len(df)
    if n < length + 3:
        return [], []

    high = df["high"].values
    low = df["low"].values
    close = df["close"].values
    vol = df["volume"].values if "volume" in df.columns else np.full(n, np.nan)
    ts = df.index

    def pivot_high_series(x: np.ndarray, L: int) -> np.ndarray:
        out = np.zeros_like(x, dtype=bool)
        for i in range(L, len(x) - L):
            if x[i] == np.max(x[i - L:i + L + 1]):
                out[i] = True
        return out

    # os серия
    os_mode = np.zeros(n, dtype=int)
    for i in range(length, n):
        up_break = high[i - length] > np.max(high[i - length - length + 1: i - length + 1]) if i - length - length + 1 >= 0 else False
        dn_break = low[i - length] < np.min(low[i - length - length + 1: i - length + 1]) if i - length - length + 1 >= 0 else False
        if up_break:
            os_mode[i] = 0
        elif dn_break:
            os_mode[i] = 1
        else:
            os_mode[i] = os_mode[i - 1] if i > 0 else 0

    # pivot high по обем (fallback към price)
    vol_ph = pivot_high_series(vol, length) if np.isfinite(vol).any() else pivot_high_series(high, length)

    bull_list: List[OBZone] = []
    bear_list: List[OBZone] = []

    atr200 = _atr(df, 200).values

    # генерирай листи от активни OB (последните ~8 са достатъчни)
    for i in range(length, n):
        if vol_ph[i] and os_mode[i] == 1:
            # Bull OB на i-length
            j = i - length
            top = 0.5 * (high[j] + low[j])  # hl2
            bottom = low[j]
            avg = (top + bottom) / 2.0
            bull_list.append(OBZone(dir="bullish", top=float(top), bottom=float(bottom), avg=float(avg),
                                    left_ts=ts[j], mitigated=False, near=False))
        if vol_ph[i] and os_mode[i] == 0:
            # Bear OB
            j = i - length
            top = high[j]
            bottom = 0.5 * (high[j] + low[j])  # hl2
            avg = (top + bottom) / 2.0
            bear_list.append(OBZone(dir="bearish", top=float(top), bottom=float(bottom), avg=float(avg),
                                    left_ts=ts[j], mitigated=False, near=False))

    # остави до 8 най-нови зони
    bull_list = bull_list[-8:]
    bear_list = bear_list[-8:]

    # mitigation & near
    c = close[-1]
    h = high[-1]
    l = low[-1]
    atr_last = atr200[-1] if np.isfinite(atr200[-1]) else (np.nanmean(atr200) if np.isfinite(atr200).any() else 0.0)
    for z in bull_list:
        target = l if mitigation == "wick" else c
        z.mitigated = bool(target < z.bottom)
        z.near = abs(c - z.avg) <= 0.25 * max(1e-8, atr_last)
    for z in bear_list:
        target = h if mitigation == "wick" else c
        z.mitigated = bool(target > z.top)
        z.near = abs(c - z.avg) <= 0.25 * max(1e-8, atr_last)

    return bull_list, bear_list


def detect_fvg(df: pd.DataFrame, width_atr_mult: float = 0.0, lookback: int = 30) -> Optional[FVG]:
    """
    3-свещов FVG:
      - bullish: low[i] > high[i-2]
      - bearish: high[i] < low[i-2]
    width_atr_mult * ATR(200) е филтър за минимална ширина на gap-а.
    """
    if len(df) < 5:
        return None
    atr200 = _atr(df, 200)
    for i in range(len(df) - 1, max(2, len(df) - lookback) - 1, -1):
        low_i = float(df["low"].iloc[i])
        high_i2 = float(df["high"].iloc[i - 2])
        high_i = float(df["high"].iloc[i])
        low_i2 = float(df["low"].iloc[i - 2])
        c = float(df["close"].iloc[-1])
        atrv = float(atr200.iloc[i])
        th = atrv * float(width_atr_mult)

        # Bullish gap
        if low_i > high_i2 and (low_i - high_i2) >= th:
            lower, upper = high_i2, low_i
            avg = (lower + upper) / 2.0
            in_gap = lower <= c <= upper
            reached = c < avg  # подобно на Lux "avg line reached"
            return FVG(dir="bullish", lower=lower, upper=upper, avg=avg, in_gap=in_gap, reached=reached, when=df.index[i])

        # Bearish gap
        if high_i < low_i2 and (low_i2 - high_i) >= th:
            lower, upper = high_i, low_i2
            avg = (lower + upper) / 2.0
            in_gap = lower <= c <= upper
            reached = c > avg
            return FVG(dir="bearish", lower=lower, upper=upper, avg=avg, in_gap=in_gap, reached=reached, when=df.index[i])
    return None


def detect_sweep(df: pd.DataFrame, len_fractal: int = 5, lookback: int = 200) -> Optional[Sweep]:
    """
    Liquidity sweep (wick): ако последната свещ прободе най-близкия swing и затвори обратно.
    """
    if len(df) < len_fractal * 2 + 5:
        return None
    hi = _pivot_high(df["high"], len_fractal, len_fractal)
    lo = _pivot_low(df["low"], len_fractal, len_fractal)
    hi_idx = hi[hi].index
    lo_idx = lo[lo].index
    if len(hi_idx) == 0 or len(lo_idx) == 0:
        return None
    last = df.iloc[-1]
    # най-близък recent swing
    last_hi_ts = hi_idx[-1]
    last_lo_ts = lo_idx[-1]
    last_hi = float(df.loc[last_hi_ts, "high"])
    last_lo = float(df.loc[last_lo_ts, "low"])

    # wick sweep
    if float(last["high"]) > last_hi and float(last["close"]) < last_hi:
        return Sweep(kind="sell", level=last_hi, when=df.index[-1])
    if float(last["low"]) < last_lo and float(last["close"]) > last_lo:
        return Sweep(kind="buy", level=last_lo, when=df.index[-1])
    return None


def analyze_smc_lux(
    df_h1: pd.DataFrame,
    *,
    swing_len: int = 50,
    internal_len: int = 5,
    ob_len: int = 5,
    ob_mitigation: Literal["wick", "close"] = "wick",
    eq_thresh_atr: float = 0.10,
    fvg_width_atr_mult: float = 0.0,
) -> SMCReport:
    """Главен анализ върху H1 (в реално време използваме последния бар)."""
    df = df_h1.copy()
    atr200 = float(_atr(df, 200).iloc[-1])

    swing_ev, last_hi, last_lo = detect_structure(df, swing_len, swing_len)
    internal_ev, _, _ = detect_structure(df, internal_len, internal_len)

    ob_bull, ob_bear = detect_ob(df, length=ob_len, mitigation=ob_mitigation)
    fvg = detect_fvg(df, width_atr_mult=fvg_width_atr_mult, lookback=30)
    sweep = detect_sweep(df, len_fractal=internal_len, lookback=200)
    eq = detect_eq(df, atr_val=atr200, left=3, right=3, thresh=eq_thresh_atr)

    # маркирай near според последна цена и ATR (ако не е изчислено в detect_ob)
    c = float(df["close"].iloc[-1])
    if atr200 <= 0:
        atr200 = float(df["close"].iloc[-100:].std() or 1.0)

    for z in ob_bull:
        z.near = z.near or (abs(c - z.avg) <= 0.25 * atr200)
    for z in ob_bear:
        z.near = z.near or (abs(c - z.avg) <= 0.25 * atr200)

    return SMCReport(
        swing=swing_ev,
        internal=internal_ev,
        ob_bull=ob_bull,
        ob_bear=ob_bear,
        fvg=fvg,
        sweep=sweep,
        eq=eq,
    )


def smc_bonus_and_conflict_lux(smc: SMCReport, signal_dir: Literal["BUY", "SELL"]) -> Tuple[int, bool, str]:
    """
    Връща (bonus [0..20], conflict, summary).
    Правила (интуитивни и близки до Lux):
      • Swing BOS/CHoCH: +8 / +6, ако съвпада с посоката; иначе конфликт.
      • Internal BOS/CHoCH: +4 / +3, ако съвпада; иначе слаб конфликт.
      • OB (near, not mitigated): +4, ако съвпада (bull near за BUY, bear near за SELL); иначе конфликт.
      • FVG: +3, ако съвпада; ако в противовес и „in_gap“, конфликт.
      • Sweep: +2, ако съвпада (sell sweep => SELL, buy sweep => BUY); иначе слаб конфликт.
      • EQH/EQL: ако EQH и SELL => +1; ако EQL и BUY => +1; обратното -1.
    """
    if smc is None:
        return 0, False, "SMC: н/д"

    parts: List[str] = []
    bonus = 0
    conflict = False

    def _al(dir_smc: Dir, want: str) -> bool:
        return (dir_smc == "bullish" and want == "BUY") or (dir_smc == "bearish" and want == "SELL")

    # Swing
    if smc.swing:
        parts.append(f"Swing {smc.swing.tag}:{'↑' if smc.swing.dir=='bullish' else '↓'}")
        if _al(smc.swing.dir, signal_dir):
            bonus += 8 if smc.swing.tag == "BOS" else 6
        else:
            conflict = True

    # Internal
    if smc.internal:
        parts.append(f"Int {smc.internal.tag}:{'↑' if smc.internal.dir=='bullish' else '↓'}")
        if _al(smc.internal.dir, signal_dir):
            bonus += 4 if smc.internal.tag == "BOS" else 3
        else:
            conflict = conflict or True

    # OB (взимаме най-близката активна)
    if signal_dir == "BUY" and smc.ob_bull:
        ob = smc.ob_bull[-1]
        parts.append(f"OBᵇ @~{ob.avg:.5f}{' near' if ob.near else ''}{' mitig' if ob.mitigated else ''}")
        if not ob.mitigated and ob.near:
            bonus += 4
        if ob.mitigated:
            conflict = conflict or True
    if signal_dir == "SELL" and smc.ob_bear:
        ob = smc.ob_bear[-1]
        parts.append(f"OBˢ @~{ob.avg:.5f}{' near' if ob.near else ''}{' mitig' if ob.mitigated else ''}")
        if not ob.mitigated and ob.near:
            bonus += 4
        if ob.mitigated:
            conflict = conflict or True

    # FVG
    if smc.fvg:
        parts.append(f"FVG:{'↑' if smc.fvg.dir=='bullish' else '↓'}{' in' if smc.fvg.in_gap else ''}{' reached' if smc.fvg.reached else ''}")
        if _al(smc.fvg.dir, signal_dir):
            bonus += 3
        elif smc.fvg.in_gap:
            conflict = conflict or True

    # Sweep
    if smc.sweep:
        parts.append(f"Sweep:{'BUY' if smc.sweep.kind=='buy' else 'SELL'}")
        if (smc.sweep.kind == "buy" and signal_dir == "BUY") or (smc.sweep.kind == "sell" and signal_dir == "SELL"):
            bonus += 2
        else:
            conflict = conflict or True

    # EQH/EQL
    if smc.eq:
        if smc.eq.eqh:
            parts.append("EQH")
            bonus += 1 if signal_dir == "SELL" else -1
        if smc.eq.eql:
            parts.append("EQL")
            bonus += 1 if signal_dir == "BUY" else -1

    bonus = max(0, min(20, bonus))
    summary = "SMC: " + (", ".join(parts) if parts else "—")
    return bonus, conflict, summary
