from __future__ import annotations

import numpy as np
import pandas as pd


def ema(series: pd.Series, period: int) -> pd.Series:
    return series.ewm(span=period, adjust=False).mean()


def macd(close: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9):
    macd_line = ema(close, fast) - ema(close, slow)
    signal_line = ema(macd_line, signal)
    hist = macd_line - signal_line
    return macd_line, signal_line, hist


def rsi(close: pd.Series, period: int = 14) -> pd.Series:
    delta = close.diff()
    gain = np.where(delta > 0, delta, 0.0)
    loss = np.where(delta < 0, -delta, 0.0)
    gain_ema = pd.Series(gain, index=close.index).ewm(alpha=1/period, adjust=False).mean()
    loss_ema = pd.Series(loss, index=close.index).ewm(alpha=1/period, adjust=False).mean()
    rs = gain_ema / (loss_ema.replace(0, np.nan))
    rsi_val = 100 - (100 / (1 + rs))
    return rsi_val.fillna(50.0)


def atr(high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14) -> pd.Series:
    prev_close = close.shift(1)
    tr = pd.concat([
        (high - low).abs(),
        (high - prev_close).abs(),
        (low - prev_close).abs(),
    ], axis=1).max(axis=1)
    return tr.rolling(period, min_periods=1).mean()


def candle_strength(open_: pd.Series, close: pd.Series, high: pd.Series, low: pd.Series) -> pd.Series:
    """
    Оценка [0..1] за сила на тялото спрямо диапазона.
    """
    body = (close - open_).abs()
    range_ = (high - low).replace(0, np.nan)
    raw = (body / range_).clip(0, 1)
    return raw.fillna(0.0)


def swing_points(high: pd.Series, low: pd.Series, left: int = 3, right: int = 3):
    """
    Намира последен swing high/low: локален максимум/минимум с прозорец left/right.
    Връща (idx_high, price_high, idx_low, price_low) или (None, None, None, None).
    """
    sh_idx = sl_idx = None
    sh = sl = None

    for i in range(left, len(high) - right):
        window_h = high.iloc[i - left:i + right + 1]
        window_l = low.iloc[i - left:i + right + 1]
        if high.iloc[i] == window_h.max():
            sh_idx = high.index[i]
            sh = float(high.iloc[i])
        if low.iloc[i] == window_l.min():
            sl_idx = low.index[i]
            sl = float(low.iloc[i])
    return sh_idx, sh, sl_idx, sl
