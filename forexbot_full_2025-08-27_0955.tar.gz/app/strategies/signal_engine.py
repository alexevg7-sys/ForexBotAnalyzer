from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import Dict, Optional

import pandas as pd

from app.strategies.indicators import ema, macd, rsi, atr, candle_strength, swing_points
from app.strategies.scoring import ScoreContext, to_confidence
from app.strategies.smc_lux import analyze_smc_lux, smc_bonus_and_conflict_lux
from app.utils.forex import round_price, pip_info, split_pair
from app.telegram_bot.formatting import SignalRender
from app.data_providers.twelvedata_client import normalize_interval


@dataclass
class EngineConfig:
    rr_base: float = 1.5
    min_confidence: int = 70
    spread_buffer_pips: float = 1.0
    smc_enabled: bool = True
    smc_strict: bool = False
    smc_params: Dict[str, object] = field(default_factory=lambda: dict(
        swing_len=50, internal_len=5, ob_len=5, ob_mitigation="wick",
        eq_thresh_atr=0.10, fvg_width_atr_mult=0.0
    ))


class SignalEngine:
    def __init__(self, data_dir: str, state_dir: str, min_confidence: int, rr_base: float):
        self.data_dir = data_dir
        self.state_path = os.path.join(state_dir, "signals_state.json")
        self.state: Dict[str, str] = self._load_state()
        self.cfg = EngineConfig(rr_base=rr_base, min_confidence=min_confidence)

    def update_params(self, min_confidence: Optional[int] = None, rr_base: Optional[float] = None,
                      smc_enabled: Optional[bool] = None, smc_strict: Optional[bool] = None,
                      smc_params: Optional[Dict[str, object]] = None):
        if min_confidence is not None:
            self.cfg.min_confidence = int(min_confidence)
        if rr_base is not None:
            self.cfg.rr_base = float(rr_base)
        if smc_enabled is not None:
            self.cfg.smc_enabled = bool(smc_enabled)
        if smc_strict is not None:
            self.cfg.smc_strict = bool(smc_strict)
        if smc_params:
            self.cfg.smc_params.update(smc_params)

    # ---------- helpers ----------
    def _csv_path(self, interval: str, pair: str) -> str:
        iv = normalize_interval(interval)
        fname = pair.replace("/", "_")
        return os.path.join(self.data_dir, "candles", iv, f"{fname}.csv")

    def _load_df(self, interval: str, pair: str) -> Optional[pd.DataFrame]:
        path = self._csv_path(interval, pair)
        if not os.path.exists(path):
            return None
        df = pd.read_csv(path)
        if df.empty or "close" not in df:
            return None
        df["datetime"] = pd.to_datetime(df["datetime"])
        df.set_index("datetime", inplace=True)
        return df

    def _save_state(self):
        try:
            with open(self.state_path, "w", encoding="utf-8") as f:
                json.dump(self.state, f)
        except Exception:
            pass

    def _load_state(self) -> Dict[str, str]:
        if os.path.exists(self.state_path):
            try:
                with open(self.state_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return {}
        return {}

    # ---------- core ----------
    def evaluate(self, pair: str, news_bias: int = 0) -> Optional[SignalRender]:
        df_h1 = self._load_df("1h", pair)
        df_m15 = self._load_df("15min", pair)
        df_h4 = self._load_df("4h", pair)
        if df_h1 is None or df_m15 is None or df_h4 is None or len(df_h1) < 60 or len(df_h4) < 60:
            return None

        # --- H4 тренд
        h4 = df_h4.copy()
        h4["ema200"] = ema(h4["close"], 200)
        h4["ema_slope"] = h4["ema200"].diff()
        h4_last = h4.iloc[-1]
        h4_trend = "up" if h4_last["close"] > h4_last["ema200"] and h4_last["ema_slope"] > 0 else \
                   ("down" if h4_last["close"] < h4_last["ema200"] and h4_last["ema_slope"] < 0 else "flat")

        # --- H1 базов сигнал
        h1 = df_h1.copy()
        h1["ema50"] = ema(h1["close"], 50)
        h1["ema50_prev"] = h1["ema50"].shift(1)
        h1["close_prev"] = h1["close"].shift(1)
        m_line, s_line, hist = macd(h1["close"])
        h1["macd_hist"] = hist
        h1["candle_pow"] = candle_strength(h1["open"], h1["close"], h1["high"], h1["low"])
        h1["atr14"] = atr(h1["high"], h1["low"], h1["close"], 14)

        last = h1.iloc[-1]
        prev = h1.iloc[-2]

        buy_cross = prev["close_prev"] <= prev["ema50_prev"] and last["close"] > last["ema50"]
        sell_cross = prev["close_prev"] >= prev["ema50_prev"] and last["close"] < last["ema50"]

        dir_sig = None
        if buy_cross and last["macd_hist"] > 0:
            dir_sig = "BUY"
        elif sell_cross and last["macd_hist"] < 0:
            dir_sig = "SELL"
        else:
            return None

        # --- M15 потвърждение (RSI)
        m15 = df_m15.copy()
        m15["rsi"] = rsi(m15["close"], 14)
        m15_last = m15.iloc[-1]
        rsi_conf = 1 if (dir_sig == "BUY" and m15_last["rsi"] >= 50) or (dir_sig == "SELL" and m15_last["rsi"] <= 50) \
            else (-1 if (dir_sig == "BUY" and m15_last["rsi"] < 45) or (dir_sig == "SELL" and m15_last["rsi"] > 55) else 0)

        # --- Структура на H1
        sh_i, sh, sl_i, sl = swing_points(h1["high"], h1["low"], left=3, right=3)
        structure_break = 0
        if dir_sig == "BUY" and sh is not None:
            structure_break = 1 if last["close"] > sh else 0
        if dir_sig == "SELL" and sl is not None:
            structure_break = 1 if last["close"] < sl else 0

        # --- Trend align
        trend_align = 1 if (h4_trend == "up" and dir_sig == "BUY") or (h4_trend == "down" and dir_sig == "SELL") else (-1 if h4_trend in ("up", "down") else 0)

        # --- MACD сила
        macd_strength = float(abs(last["macd_hist"])) / float(h1["close"].iloc[-100:].std() + 1e-8)
        macd_strength = max(0.0, min(1.0, macd_strength))

        # --- Candle power
        candle_pow = float(last["candle_pow"])

        # --- News bias
        news_bias_clamped = max(-2, min(2, int(news_bias)))

        # --- Lux SMC (ако е активен)
        smc_summary = "SMC: OFF"
        extra_bonus = 0
        if self.cfg.smc_enabled:
            p = self.cfg.smc_params
            smc = analyze_smc_lux(
                h1,
                swing_len=int(p.get("swing_len", 50)),
                internal_len=int(p.get("internal_len", 5)),
                ob_len=int(p.get("ob_len", 5)),
                ob_mitigation=str(p.get("ob_mitigation", "wick")),
                eq_thresh_atr=float(p.get("eq_thresh_atr", 0.10)),
                fvg_width_atr_mult=float(p.get("fvg_width_atr_mult", 0.0)),
            )
            extra_bonus, smc_conflict, smc_summary = smc_bonus_and_conflict_lux(smc, dir_sig)
            if self.cfg.smc_strict and smc_conflict:
                return None

        # --- Скорираме
        ctx = ScoreContext(
            trend_align=trend_align,
            macd_strength=macd_strength,
            rsi_confirm=rsi_conf,
            candle_power=candle_pow,
            structure_break=structure_break,
            news_bias=news_bias_clamped,
            extra_bonus=extra_bonus,
        )
        confidence = to_confidence(ctx)
        if confidence < self.cfg.min_confidence:
            return None

        # --- ENTRY/SL/TP
        entry = float(last["close"])
        atr14 = float(h1["atr14"].iloc[-1])
        pip, dec = pip_info(pair)

        if dir_sig == "BUY":
            sl_candidate = min(sl if sl is not None else entry, entry - 1.2 * atr14)
            slp = min(sl_candidate, entry - 0.6 * atr14)
            risk = entry - slp
            tp1 = entry + risk * 1.0
            tp2 = entry + risk * self.cfg.rr_base
            entry_adj = entry + self.cfg.spread_buffer_pips * pip
        else:
            sh_val = sh if sh is not None else entry
            sl_candidate = max(sh_val, entry + 1.2 * atr14)
            slp = max(sl_candidate, entry + 0.6 * atr14)
            risk = slp - entry
            tp1 = entry - risk * 1.0
            tp2 = entry - risk * self.cfg.rr_base
            entry_adj = entry - self.cfg.spread_buffer_pips * pip

        entry_adj = round_price(pair, entry_adj)
        slp = round_price(pair, slp)
        tp1 = round_price(pair, tp1)
        tp2 = round_price(pair, tp2)

        bar_id = h1.index[-1].strftime("%Y%m%d%H")
        sig_key = f"{pair}:{bar_id}:{dir_sig}"
        if self.state.get(sig_key):
            return None
        self.state[sig_key] = "sent"
        if len(self.state) > 5000:
            self.state = dict(list(self.state.items())[-3000:])
        self._save_state()

        base, quote = split_pair(pair)
        context = f"H4 тренд: {h4_trend}. M15 RSI: {int(m15_last['rsi'])}. News bias: {news_bias}."
        if smc_summary:
            context += f" | {smc_summary}"

        render = SignalRender(
            pair=pair,
            timeframe="H1",
            direction=dir_sig,
            entry=entry_adj,
            sl=slp,
            tp_levels=[tp1, tp2],
            confidence=int(confidence),
            context=context,
        )
        return render
