from __future__ import annotations

import glob
import json
import os
import subprocess
from pathlib import Path
import pandas as pd

from app.utils.news_scoring import analyze_and_format

BASE = Path("/OPT/forexbot")
OHLC = BASE / "data" / "ohlc"
NEWS_JSONL = BASE / "data" / "news" / "scores.jsonl"
NEWS_JSON  = BASE / "data" / "news" / "scores.json"

def section(title: str):
    print("\n" + "="*len(title))
    print(title)
    print("="*len(title))

def sh(cmd: str) -> str:
    try:
        out = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, text=True)
        return out.strip()
    except subprocess.CalledProcessError as e:
        return (e.output or "").strip()

def check_service():
    section("SYSTEMD / JOURNAL")
    print(sh("systemctl is-active forexbot || true"))
    print(sh("systemctl status forexbot --no-pager -l | tail -n 10"))
    print("-- last ERROR/WARNING (2h) --")
    print(sh("journalctl -u forexbot --since 2
