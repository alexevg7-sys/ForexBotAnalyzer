from __future__ import annotations
import os, json, glob
import pandas as pd
from datetime import datetime, timezone

BASE="/OPT/forexbot/data"

def last_rows():
    paths = sorted(glob.glob(os.path.join(BASE,"ohlc","*.csv")))
    by_pair={}
    for p in paths:
        name=os.path.basename(p).replace(".csv","")
        try:
            df=pd.read_csv(p, parse_dates=["datetime"])
            if df.empty: 
                continue
            last=df.tail(1).iloc[0]
            pair, tf = name.rsplit("_",1)
            by_pair.setdefault(pair, {})[tf]={
                "ts": str(last["datetime"]),
                "close": float(last["close"])
            }
        except Exception:
            pass
    return by_pair

def recent_news(n=3):
    path=os.path.join(BASE,"news","scores.jsonl")
    out=[]
    if os.path.exists(path):
        with open(path,"r",encoding="utf-8") as f:
            lines=f.readlines()[-n:]
        for ln in lines:
            try:
                j=json.loads(ln)
                out.append({
                    "ts": j.get("ts"),
                    "stars": j.get("stars"),
                    "EUR": j.get("trends",{}).get("EUR"),
                    "USD": j.get("trends",{}).get("USD"),
                    "title": (j.get("title_bg","") or "")[:80]
                })
            except Exception:
                pass
    return out

if __name__=="__main__":
    print("=== OHLC snapshot ===")
    snap = last_rows()
    for pair, tfs in list(snap.items())[:10]:
        row = ", ".join(f"{tf}@{v['ts']} close={v['close']}" for tf,v in sorted(tfs.items()))
        print(f"{pair}: {row}")

    print("\n=== Recent news ===")
    for n in recent_news():
        try:
            dt=datetime.fromtimestamp(int(n["ts"]), tz=timezone.utc)
            when = dt.isoformat()
        except Exception:
            when = "?"
        eur = n["EUR"]
        usd = n["USD"]
        print(f"{when}  ★{n['stars']}  EUR={eur} USD={usd}  {n['title']}")
    print("\nOK")
