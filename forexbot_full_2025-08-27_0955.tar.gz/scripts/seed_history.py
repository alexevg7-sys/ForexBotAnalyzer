from __future__ import annotations
import asyncio, os, sys

# вижда корена на проекта
sys.path.insert(0, "/OPT/forexbot")

from app.data_providers.twelvedata_client import TwelveDataClient
from app.services.market_cache import MarketCache

def load_env_file(path: str):
    if not os.path.exists(path):
        return
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith("#") or "=" not in s:
                continue
            k, v = s.split("=", 1)
            v = v.strip().strip('"').strip("'")
            os.environ.setdefault(k.strip(), v)

PAIRS = [
 "EUR/USD","GBP/USD","USD/JPY","USD/CHF","AUD/USD","NZD/USD","USD/CAD",
 "EUR/GBP","EUR/JPY","GBP/JPY","AUD/JPY","CAD/JPY","CHF/JPY",
 "EUR/CHF","GBP/CHF",
 "EUR/AUD","EUR/CAD","GBP/CAD",
 "AUD/NZD","AUD/CAD",
 "NZD/JPY","NZD/CHF",
 "EUR/NZD","GBP/NZD",
 "USD/SEK","USD/NOK","USD/TRY","USD/ZAR"
]

# достатъчно за 14д/30д/120д + буфер
OUTPUTSIZE = {"15min": 1500, "1h": 1100, "4h": 900}

async def main():
    # ако няма ключ – зареди /etc/forexbot/forexbot.env
    if not os.getenv("TWELVEDATA_API_KEY"):
        load_env_file("/etc/forexbot/forexbot.env")

    api_key = os.getenv("TWELVEDATA_API_KEY")
    if not api_key:
        raise RuntimeError("Липсва TWELVEDATA_API_KEY – добави го в /etc/forexbot/forexbot.env или в env!")

    td = TwelveDataClient(api_key, rate_limit_per_min=55)
    cache = MarketCache("/OPT/forexbot/data")  # с пер-TF ретенция
    total = 0
    requests = 0

    for p in PAIRS:
        for tf, out in OUTPUTSIZE.items():
            df = await td.fetch_ohlc(p, tf, outputsize=out)
            requests += 1
            if df is not None and not df.empty:
                cache.save(p, tf, df)
                print(f"[seed] {p} {tf}: {len(df)} rows")
                total += len(df)
            # проста дозация: ~1.2 s между заявки (~50/мин)
            await asyncio.sleep(1.2)

    await td.aclose()
    print(f"OK, seeded ~{total} rows from {requests} requests")

if __name__ == "__main__":
    asyncio.run(main())
