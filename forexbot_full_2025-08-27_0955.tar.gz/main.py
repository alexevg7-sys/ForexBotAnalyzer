#!/usr/bin/env python3
from __future__ import annotations

import asyncio
import os
import signal
import sys

from app.utils.config import Settings as _Settings
from app.utils.logger import configure_logging, get_logger
from app.utils.cleanup import purge_old_files
from app.telegram_bot.bot import build_application, start_polling, stop_polling, Notifier
from app.telegram_bot.commands import register_commands
from app.data_providers.finnhub_client import FinnhubClient
from app.data_providers.deepl_client import DeepLClient
from app.services.news_poller import NewsPoller
from app.data_providers.twelvedata_client import TwelveDataClient
from app.services.market_cache import MarketCache
from app.services.market_poller import MarketPoller
from app.services.signal_scheduler import SignalScheduler
from app.services.control import ControlStore, ControlState, Control


async def housekeeping_loop(settings: _Settings, logger):
    while True:
        try:
            stats = purge_old_files(
                paths=[settings.data_dir, settings.state_dir, settings.tmp_dir, settings.log_dir],
                older_than_days=settings.data_retention_days,
                logger=logger,
            )
            if any(stats.values()):
                logger.info("housekeeping:purge", extra={"stats": stats})
        except Exception as e:
            logger.error("housekeeping:error", extra={"err": str(e)})
        await asyncio.sleep(30 * 60)


async def run():
    configure_logging()
    logger = get_logger("forexbot")

    settings = _Settings.from_env()
    configure_logging(level=settings.log_level, log_dir=settings.log_dir)
    logger = get_logger("forexbot")

    logger.info("app:start", extra={"summary": settings.safe_summary()})

    for p in [settings.data_dir, settings.state_dir, settings.tmp_dir, settings.log_dir]:
        os.makedirs(p, exist_ok=True)

    control_store = ControlStore(os.path.join(settings.state_dir, "control.json"))
    control_defaults = ControlState(
        signals_enabled=True,
        news_enabled=True,
        signal_min_confidence=settings.signal_min_confidence,
        risk_rr_base=settings.risk_rr_base,
        pairs_active=list(settings.default_pairs),
        silent_mode=False,
        smc_enabled=True,
        smc_strict=False,
        smc_swing_len=50,
        smc_internal_len=5,
        smc_ob_len=5,
        smc_mitigation="wick",
        smc_eq_thresh_atr=0.10,
        smc_fvg_width_atr_mult=0.0,
    )
    control = Control(control_store, control_defaults)

    tg_app = build_application(settings.telegram_bot_token, app_summary=settings.safe_summary())
    # дадем data_dir на командите (за /backtest)
    tg_app.bot_data["data_dir"] = settings.data_dir
    register_commands(tg_app, control, settings.telegram_target_chat_id)
    notifier = Notifier(tg_app, settings.telegram_target_chat_id, rate_limit_per_min=settings.rate_limit_per_min)

    finnhub = FinnhubClient(settings.finnhub_api_key, rate_limit_per_min=settings.rate_limit_per_min)
    deepl = DeepLClient(settings.deepl_api_key, rate_limit_per_min=settings.rate_limit_per_min)
    news_poller = NewsPoller(
        state_dir=settings.state_dir,
        data_dir=settings.data_dir,
        finnhub=finnhub,
        deepl=deepl,
        notifier=notifier,
        refresh_seconds=settings.news_refresh_seconds,
        control=control,
    )

    td = TwelveDataClient(settings.twelvedata_api_key, rate_limit_per_min=settings.rate_limit_per_min)
    cache = MarketCache(settings.data_dir, retention_days=settings.data_retention_days)
    market = MarketPoller(
        td=td,
        cache=cache,
        pairs=settings.default_pairs,
        tf_h1=settings.tf_h1,
        tf_m15=settings.tf_m15,
        tf_h4=settings.tf_h4,
        poll_interval_seconds=settings.poll_interval_seconds,
        outputsize=120,
    )

    signals = SignalScheduler(
        data_dir=settings.data_dir,
        state_dir=settings.state_dir,
        pairs=settings.default_pairs,
        notifier=notifier,
        min_confidence=settings.signal_min_confidence,
        rr_base=settings.risk_rr_base,
        interval_seconds=max(20, settings.poll_interval_seconds),
        control=control,
    )

    tasks = [
        asyncio.create_task(housekeeping_loop(settings, logger), name="housekeeping"),
        asyncio.create_task(start_polling(tg_app), name="telegram"),
        asyncio.create_task(news_poller.run_forever(), name="news"),
        asyncio.create_task(market.run_forever(), name="market"),
        asyncio.create_task(signals.run_forever(), name="signals"),
    ]

    try:
        if not (await control.silent_mode()):
            await notifier.send_text("⚙️ /config за SMC параметри и /backtest EUR/USD 1000 за бектест върху кеша.")
    except Exception as e:
        logger.warning("telegram:welcome:error", extra={"err": str(e)})

    stop_event = asyncio.Event()

    def _handle_signal(sig):
        logger.warning("app:signal", extra={"signal": int(sig)})
        stop_event.set()

    loop = asyncio.get_running_loop()
    for s in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(s, _handle_signal, s)
        except NotImplementedError:
            pass

    await stop_event.wait()
    logger.info("app:stopping")

    try:
        await stop_polling(tg_app)
    except Exception as e:
        logger.error("telegram:stop:error", extra={"err": str(e)})

    for t in tasks:
        if t.get_name() != "telegram":
            t.cancel()
    await asyncio.gather(*tasks, return_exceptions=True)

    try:
        await finnhub.aclose()
    except Exception:
        pass
    try:
        await td.aclose()
    except Exception:
        pass

    logger.info("app:stopped")


def main():
    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(f"[fatal] {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
